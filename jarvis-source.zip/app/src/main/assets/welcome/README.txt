JARVIS v0.4.0 bundled startup greetings.

The WAV files are pre-generated with the HFC Male Piper model using the tuned Termux settings:
length scale 0.90
noise scale 0.667
noise scale W 0.80
threads 4

See manifest.txt for the greeting mapping.
