package com.jarvis.local.voice;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;

import com.jarvis.local.core.DebugLog;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/** Handles instant bundled startup greetings, with TTS fallback until greeting WAV assets are packaged. */
public final class WelcomeManager {
    public interface Callback { void onDone(); void onError(Throwable error); }
    private static final String[] FALLBACK = {
            "Good morning. JARVIS is online.",
            "Good morning. All systems are ready.",
            "Good afternoon. JARVIS is online and ready.",
            "Good afternoon. Systems are fully initialized.",
            "Good evening. JARVIS is online.",
            "Good evening. All systems are ready.",
            "Welcome back. JARVIS is ready.",
            "Welcome back. All systems are online.",
            "Systems initialized. JARVIS is ready.",
            "JARVIS is online. Everything is ready.",
            "Core systems are online. Welcome back.",
            "JARVIS is ready. Let's get started."
    };
    private final Context context;
    private final Random random = new Random();

    public WelcomeManager(Context context) { this.context = context.getApplicationContext(); }

    public void play(TtsManager tts, Callback callback) {
        if (!context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("welcome_speech", true)) {
            if (callback != null) callback.onDone();
            return;
        }
        boolean variation = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("welcome_variation", true);
        int index = variation ? random.nextInt(12) + 1 : 1;
        String asset = "welcome/welcome_" + String.format(java.util.Locale.US, "%02d", index) + ".wav";
        new Thread(() -> {
            try {
                if (playAsset(asset)) {
                    DebugLog.write(context, "Welcome audio played asset=" + asset);
                    if (callback != null) callback.onDone();
                    return;
                }
            } catch (Throwable e) {
                DebugLog.write(context, "Welcome asset unavailable: " + e.getMessage());
            }
            boolean fallbackVariation = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("welcome_variation", true);
            String greeting = FALLBACK[fallbackVariation ? random.nextInt(FALLBACK.length) : 0];
            DebugLog.write(context, "Welcome audio fallback TTS");
            tts.speak(greeting, new TtsManager.Callback() {
                public void onStarted(String sentence) {}
                public void onSentenceDone(String sentence) {}
                public void onAllDone() { if (callback != null) callback.onDone(); }
                public void onError(Throwable error) { if (callback != null) callback.onError(error); }
            });
        }, "JARVIS-Welcome").start();
    }

    private boolean playAsset(String name) throws Exception {
        AssetFileDescriptor afd;
        try { afd = context.getAssets().openFd(name); } catch (Exception e) { return false; }
        try (InputStream in = afd.createInputStream()) {
            byte[] header = new byte[44];
            int read = 0;
            while (read < header.length) { int n = in.read(header, read, header.length - read); if (n < 0) return false; read += n; }
            if (header[0] != 'R' || header[1] != 'I' || header[2] != 'F' || header[3] != 'F'
                    || header[8] != 'W' || header[9] != 'A' || header[10] != 'V' || header[11] != 'E') return false;
            int channels = le16(header, 22);
            int sampleRate = le32(header, 24);
            int bits = le16(header, 34);
            if (channels != 1 || bits != 16 || sampleRate <= 0) return false;
            byte[] pcm = readAll(in);
            AudioTrack track = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                    .setAudioFormat(new AudioFormat.Builder().setSampleRate(sampleRate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(Math.max(AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT), 4096))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
            try {
                track.play();
                track.write(pcm, 0, pcm.length);
                track.stop();
            } finally { track.release(); }
            return true;
        } finally { afd.close(); }
    }

    private static int le16(byte[] b, int i) { return (b[i] & 255) | ((b[i+1] & 255) << 8); }
    private static int le32(byte[] b, int i) { return (b[i] & 255) | ((b[i+1] & 255) << 8) | ((b[i+2] & 255) << 16) | ((b[i+3] & 255) << 24); }
    private static byte[] readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
        return out.toByteArray();
    }
}
