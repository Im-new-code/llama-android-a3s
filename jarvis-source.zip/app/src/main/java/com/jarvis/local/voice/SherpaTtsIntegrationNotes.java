package com.jarvis.local.voice;

/**
 * Integration target for the Sherpa ONNX AAR.
 *
 * The intended bridge is:
 *
 *   OfflineTts
 *       -> OfflineTtsVitsModelConfig
 *       -> OfflineTtsConfig
 *       -> GenerationConfig
 *       -> generated PCM samples
 *       -> AudioTrack
 *
 * Keep all Sherpa specific imports inside this file/package. That lets the
 * rest of the app remain independent of the exact Sherpa API version.
 *
 * Piper settings selected for JARVIS:
 *
 *   length scale : 0.90
 *   noise scale  : 0.667
 *   noise W      : 0.80
 *   threads      : 4
 *   speed        : 1.0
 */
public final class SherpaTtsIntegrationNotes {
    private SherpaTtsIntegrationNotes() {}
}
