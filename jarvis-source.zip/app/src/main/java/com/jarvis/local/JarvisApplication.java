package com.jarvis.local;

import android.app.Application;

import com.jarvis.local.ai.LlamaCliEngine;
import com.jarvis.local.ai.LlmEngine;
import com.jarvis.local.voice.TtsManager;

/** Process-wide JARVIS runtime. Keeps the warmed engines alive while the app process lives. */
public final class JarvisApplication extends Application {
    private LlamaCliEngine llm;
    private TtsManager tts;

    @Override public void onCreate() {
        super.onCreate();
        llm = new LlamaCliEngine(this);
        tts = new TtsManager(this);
    }

    public LlamaCliEngine getLlm() { return llm; }
    public TtsManager getTts() { return tts; }
}
