package com.jarvis.local;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.jarvis.local.ai.LlamaCliEngine;
import com.jarvis.local.core.DebugLog;
import com.jarvis.local.core.StoragePathResolver;
import com.jarvis.local.ui.StartupBootView;
import com.jarvis.local.voice.TtsManager;

import java.io.File;
import java.util.concurrent.atomic.AtomicBoolean;

public final class StartupActivity extends Activity {
    private static final int STORAGE_REQUEST = 9201;
    private static final String FIXED_ROOT = "/storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models";
    private StartupBootView boot;
    private TextView detail;
    private TextView action;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final AtomicBoolean llmDone = new AtomicBoolean(false);
    private final AtomicBoolean ttsDone = new AtomicBoolean(false);
    private boolean failed;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(5, 7, 12));
        getWindow().setNavigationBarColor(Color.rgb(5, 7, 12));
        getWindow().getDecorView().setSystemUiVisibility(0);
        buildUi();
        initializeDefaults();
        DebugLog.init(this);
        main.postDelayed(this::begin, 180);
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(android.view.Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(Color.rgb(5, 7, 12));
        root.setPadding(dp(24), dp(32), dp(24), dp(28));

        boot = new StartupBootView(this);
        root.addView(boot, new LinearLayout.LayoutParams(-1, 0, 1));

        detail = new TextView(this);
        detail.setTextColor(Color.rgb(145,157,178));
        detail.setTextSize(11);
        detail.setGravity(android.view.Gravity.CENTER);
        detail.setText("Preparing startup…");
        root.addView(detail, new LinearLayout.LayoutParams(-1, dp(42)));

        action = new TextView(this);
        action.setTextColor(Color.rgb(107,231,255));
        action.setTextSize(12);
        action.setGravity(android.view.Gravity.CENTER);
        action.setVisibility(TextView.GONE);
        root.addView(action, new LinearLayout.LayoutParams(-1, dp(48)));
        setContentView(root);
    }

    private void initializeDefaults() {
        android.content.SharedPreferences p = getSharedPreferences("jarvis", MODE_PRIVATE);
        android.content.SharedPreferences.Editor e = p.edit();
        if (!p.contains("animations")) e.putBoolean("animations", true);
        if (!p.contains("auto_speak")) e.putBoolean("auto_speak", true);
        if (!p.contains("welcome_speech")) e.putBoolean("welcome_speech", true);
        if (!p.contains("welcome_variation")) e.putBoolean("welcome_variation", true);
        if (!p.contains("welcome_personalized")) e.putBoolean("welcome_personalized", true);
        if (!p.contains("ai_preload")) e.putBoolean("ai_preload", true);
        if (!p.contains("tts_preload")) e.putBoolean("tts_preload", true);
        if (!p.contains("debug_logging")) e.putBoolean("debug_logging", true);
        if (!p.contains("debug_verbose_native")) e.putBoolean("debug_verbose_native", true);
        if (!p.contains("tts_threads4")) e.putBoolean("tts_threads4", true);
        e.apply();
    }

    private void begin() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            detail.setText("Storage access is required before local AI initialization");
            action.setVisibility(TextView.VISIBLE);
            action.setText("ALLOW STORAGE ACCESS");
            action.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_REQUEST));
            return;
        }
        initializeLocalSystems();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode, permissions, grants);
        if (requestCode != STORAGE_REQUEST) return;
        if (grants.length > 0 && grants[0] == PackageManager.PERMISSION_GRANTED) {
            action.setVisibility(TextView.GONE);
            initializeLocalSystems();
        } else {
            detail.setText("Storage access was denied. JARVIS cannot access its local models.");
            action.setVisibility(TextView.VISIBLE);
            action.setText("ALLOW STORAGE ACCESS");
            action.setOnClickListener(v -> requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, STORAGE_REQUEST));
        }
    }

    private void initializeLocalSystems() {
        action.setVisibility(TextView.GONE);
        File llmModel = StoragePathResolver.fixedSmolModel();
        File ttsModel = StoragePathResolver.fixedHfcMaleDirectory();
        if (llmModel == null || ttsModel == null) {
            failed = true;
            boot.setPhase(StartupBootView.Phase.ERROR);
            String missing = llmModel == null && ttsModel == null ? "SmolLM2 and HFC Male models are missing."
                    : llmModel == null ? "SmolLM2 GGUF is missing." : "HFC Male voice model is missing.";
            detail.setText(missing + "\nExpected location:\n" + FIXED_ROOT);
            action.setVisibility(TextView.VISIBLE);
            action.setText("RETRY MODEL CHECK");
            action.setOnClickListener(v -> { failed = false; initializeLocalSystems(); });
            DebugLog.write(this, "Startup model validation failed llm=" + (llmModel != null) + ", tts=" + (ttsModel != null));
            return;
        }

        JarvisApplication app = (JarvisApplication)getApplication();
        boot.setPhase(StartupBootView.Phase.INITIALIZING);
        detail.setText("Verifying local models…");
        DebugLog.write(this, "Startup fixed model path validated");

        if (!getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("ai_preload", true)) {
            llmDone.set(true);
        } else app.getLlm().preload(new LlamaCliEngine.PreloadCallback() {
            @Override public void onStarted() { main.post(() -> detail.setText("LOCAL AI  •  loading SmolLM2")); }
            @Override public void onComplete() { llmDone.set(true); maybeReady(); }
            @Override public void onError(Throwable error) { fail("Local AI initialization failed: " + error.getMessage(), error); }
        });
        if (!getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("tts_preload", true)) {
            ttsDone.set(true);
        } else app.getTts().preload(new TtsManager.PreloadCallback() {
            @Override public void onStarted() { main.post(() -> detail.setText("VOICE ENGINE  •  loading HFC Male")); }
            @Override public void onComplete() { ttsDone.set(true); maybeReady(); }
            @Override public void onError(Throwable error) { fail("Voice engine initialization failed: " + error.getMessage(), error); }
        });        maybeReady();
    }

    private void maybeReady() {
        if (!llmDone.get() || !ttsDone.get() || failed) return;
        main.post(() -> {
            boot.setPhase(StartupBootView.Phase.READY);
            detail.setText("LOCAL AI  ✓    VOICE ENGINE  ✓    SYSTEMS  ✓");
            main.postDelayed(this::finishStartup, 420);
        });
    }

    private void finishStartup() {
        if (failed) return;
        JarvisApplication app = (JarvisApplication)getApplication();
        detail.setText("SYSTEMS ONLINE  •  WELCOME");
        new com.jarvis.local.voice.WelcomeManager(this).play(app.getTts(), new com.jarvis.local.voice.WelcomeManager.Callback() {
            @Override public void onDone() { launchMain(); }
            @Override public void onError(Throwable error) {
                DebugLog.write(StartupActivity.this, "Welcome error=" + error.getMessage());
                launchMain();
            }
        });
    }

    private void launchMain() {
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    private void fail(String message, Throwable error) {
        failed = true;
        DebugLog.write(this, "Startup error=" + message);
        main.post(() -> {
            boot.setPhase(StartupBootView.Phase.ERROR);
            detail.setText(message);
            action.setVisibility(TextView.VISIBLE);
            action.setText("RETRY INITIALIZATION");
            action.setOnClickListener(v -> { failed = false; llmDone.set(false); ttsDone.set(false); initializeLocalSystems(); });
        });
    }


    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
}
