package com.jarvis.local.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import com.jarvis.local.StartupActivity;
import com.jarvis.local.R;

public final class JarvisWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_OPEN = "com.jarvis.local.ACTION_WIDGET_OPEN";
    public static final String ACTION_SPEAK = "com.jarvis.local.ACTION_WIDGET_SPEAK";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        updateAll(context, manager);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_OPEN.equals(intent.getAction())) {
            Intent open = new Intent(context, StartupActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(open);
        } else if (ACTION_SPEAK.equals(intent.getAction())) {
            Intent open = new Intent(context, StartupActivity.class);
            open.putExtra("widget_voice", true);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            context.startActivity(open);
        }
    }

    private static void updateAll(Context context, AppWidgetManager manager) {
        ComponentName component = new ComponentName(context, JarvisWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_jarvis);
            Intent open = new Intent(context, StartupActivity.class);
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent openPending = PendingIntent.getActivity(
                    context, id, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            Intent speak = new Intent(context, JarvisWidgetProvider.class);
            speak.setAction(ACTION_SPEAK);
            PendingIntent speakPending = PendingIntent.getBroadcast(
                    context, id + 10000, speak,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

            views.setOnClickPendingIntent(R.id.widget_root, openPending);
            views.setOnClickPendingIntent(R.id.widget_mic, speakPending);
            manager.updateAppWidget(id, views);
        }
    }
}
