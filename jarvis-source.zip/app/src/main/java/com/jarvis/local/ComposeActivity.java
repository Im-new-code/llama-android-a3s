package com.jarvis.local;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class ComposeActivity extends Activity {
    private EditText editor;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,float size,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);return t;}

    @Override protected void onCreate(Bundle b){
        super.onCreate(b); requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE|android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        final int bg=Color.rgb(7,9,14),fg=Color.rgb(244,247,251),muted=Color.rgb(145,157,178),accent=Color.rgb(107,231,255);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(dp(18),dp(12),dp(18),dp(18));
        LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
        ImageButton close=new ImageButton(this);close.setImageResource(R.drawable.ic_close);close.setColorFilter(Color.WHITE);close.setBackgroundResource(R.drawable.bg_icon_button);close.setContentDescription("Close");close.setOnClickListener(v->finish());top.addView(close,new LinearLayout.LayoutParams(dp(48),dp(48)));
        TextView title=text("New message",19,fg);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);title.setGravity(Gravity.CENTER_VERTICAL);top.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        ImageButton send=new ImageButton(this);send.setImageResource(R.drawable.ic_send);send.setColorFilter(accent);send.setBackgroundResource(R.drawable.bg_icon_button);send.setContentDescription("Send message");top.addView(send,new LinearLayout.LayoutParams(dp(48),dp(48)));root.addView(top);
        TextView sub=text("Write comfortably in a full screen editor",11,muted);sub.setPadding(dp(3),dp(10),dp(3),dp(12));root.addView(sub);
        editor=new EditText(this);editor.setTextColor(fg);editor.setHintTextColor(muted);editor.setHint("Message JARVIS…");editor.setTextSize(17);editor.setGravity(Gravity.TOP);editor.setSingleLine(false);editor.setBackgroundResource(R.drawable.bg_composer);editor.setPadding(dp(17),dp(15),dp(17),dp(15));
        editor.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        String draft=getIntent().getStringExtra("draft");if(draft!=null)editor.setText(draft);editor.setSelection(editor.length());root.addView(editor,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=text("Your message stays in the local conversation layer.",10,muted);foot.setGravity(Gravity.CENTER);foot.setPadding(0,dp(10),0,0);root.addView(foot);
        send.setOnClickListener(v->finishWithMessage());
        setContentView(root); editor.requestFocus();
    }
    private void finishWithMessage(){String s=editor.getText().toString().trim();if(s.isEmpty())return;Intent i=new Intent();i.putExtra("message",s);setResult(RESULT_OK,i);((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(editor.getWindowToken(),0);finish();}
}
