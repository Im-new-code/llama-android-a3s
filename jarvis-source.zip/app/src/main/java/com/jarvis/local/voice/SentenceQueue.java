package com.jarvis.local.voice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class SentenceQueue {

    private static final Pattern SPLIT =
            Pattern.compile("(?<=[.!?])\\s+");

    public static List<String> split(String text) {
        List<String> result = new ArrayList<>();
        if (text == null) return result;

        String clean = text.trim();
        if (clean.isEmpty()) return result;

        String[] parts = SPLIT.split(clean);
        for (String part : parts) {
            String sentence = part.trim();
            if (!sentence.isEmpty()) result.add(sentence);
        }
        return result;
    }

    private SentenceQueue() {}
}
