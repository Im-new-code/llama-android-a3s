package com.jarvis.local.voice;

public interface SttEngine {
    interface Callback {
        void onPartial(String text);
        void onFinal(String text);
        void onError(Throwable error);
    }

    boolean isReady();

    void start(Callback callback);

    void stop();

    void release();
}
