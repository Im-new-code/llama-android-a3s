package com.jarvis.local;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.jarvis.local.ai.LlmEngine;
import com.jarvis.local.ai.PlaceholderLlmEngine;
import com.jarvis.local.core.ConversationManager;
import com.jarvis.local.core.Message;
import com.jarvis.local.ui.GlowOrbView;
import com.jarvis.local.voice.SentenceQueue;
import com.jarvis.local.voice.TtsManager;

import java.util.List;

public final class MainActivity extends Activity {

    private LinearLayout messagesContainer;
    private ScrollView scroll;
    private EditText input;
    private TextView status;
    private ConversationManager conversation;
    private LlmEngine llm;
    private TtsManager tts;
    private boolean animateUi = true;

    private final int bg = Color.rgb(9, 11, 16);
    private final int text = Color.rgb(244, 247, 251);
    private final int muted = Color.rgb(147, 160, 181);
    private final int accent = Color.rgb(107, 231, 255);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        conversation = new ConversationManager();
        llm = new PlaceholderLlmEngine();
        tts = new TtsManager(this);

        buildUi();
    }

    private TextView label(String value, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        return tv;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(18, 14, 18, 10);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        GlowOrbView orb = new GlowOrbView(this);
        header.addView(orb, new LinearLayout.LayoutParams(58, 58));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(12, 0, 0, 0);

        TextView title = label("JARVIS", 21, text);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        status = label("LOCAL • READY", 11, muted);

        titleBox.addView(title);
        titleBox.addView(status);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        TextView settings = label("⚙", 24, text);
        settings.setGravity(Gravity.CENTER);
        settings.setOnClickListener(v -> startActivity(
                new Intent(this, SettingsActivity.class)
        ));
        header.addView(settings, new LinearLayout.LayoutParams(48, 48));

        root.addView(header);

        TextView line = label(
                "Private local assistant • no cloud required",
                12,
                muted
        );
        line.setPadding(8, 0, 0, 12);
        root.addView(line);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);

        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setPadding(0, 8, 0, 10);

        scroll.addView(messagesContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(
                -1, 0, 1
        ));

        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);

        input = new EditText(this);
        input.setTextColor(text);
        input.setHintTextColor(muted);
        input.setHint("Talk to JARVIS…");
        input.setTextSize(15);
        input.setSingleLine(false);
        input.setMaxLines(4);
        input.setPadding(16, 10, 12, 10);
        input.setBackgroundResource(com.jarvis.local.R.drawable.bg_input);

        LinearLayout.LayoutParams inputParams =
                new LinearLayout.LayoutParams(0, 58, 1);
        inputParams.setMargins(0, 0, 8, 0);
        inputRow.addView(input, inputParams);

        ImageButton send = new ImageButton(this);
        send.setImageResource(android.R.drawable.ic_media_play);
        send.setColorFilter(accent);
        send.setBackgroundResource(com.jarvis.local.R.drawable.bg_surface_soft);
        send.setContentDescription("Send");
        send.setOnClickListener(v -> sendMessage());

        inputRow.addView(send, new LinearLayout.LayoutParams(54, 54));
        root.addView(inputRow);

        TextView hint = label(
                "Voice mode and wake word will plug into this same conversation layer.",
                10,
                muted
        );
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 8, 0, 0);
        root.addView(hint);

        setContentView(root);

        addMessage(
                Message.Role.ASSISTANT,
                "Good to see you. I am JARVIS.\n\nThe interface is online. "
                        + "My local model bridge is the next component to connect."
        );
    }

    private void sendMessage() {
        String userText = input.getText().toString().trim();
        if (userText.isEmpty()) return;

        input.setText("");
        conversation.addUser(userText);
        addMessage(Message.Role.USER, userText);
        status.setText("LOCAL • THINKING");

        llm.generate(userText, new LlmEngine.Callback() {
            @Override
            public void onToken(String token) {}

            @Override
            public void onComplete(String fullText) {
                conversation.addAssistant(fullText);
                addMessage(Message.Role.ASSISTANT, fullText);
                status.setText("LOCAL • READY");

                // Future setting will control automatic TTS.
                if (getPreferences(MODE_PRIVATE)
                        .getBoolean("auto_speak", false)) {
                    List<String> queue = SentenceQueue.split(fullText);
                    tts.speakQueue(queue, new TtsManager.Callback() {
                        @Override public void onStarted(String sentence) {
                            status.setText("LOCAL • SPEAKING");
                        }
                        @Override public void onSentenceDone(String sentence) {}
                        @Override public void onAllDone() {
                            status.setText("LOCAL • READY");
                        }
                        @Override public void onError(Throwable error) {
                            status.setText("LOCAL • TTS ERROR");
                        }
                    });
                }
            }

            @Override
            public void onError(Throwable error) {
                status.setText("LOCAL • ERROR");
                addMessage(
                        Message.Role.ASSISTANT,
                        "I hit a local error: " + error.getMessage()
                );
            }
        });
    }

    private void addMessage(Message.Role role, String body) {
        TextView tv = label(body, 15, text);
        tv.setPadding(16, 13, 16, 13);
        tv.setTextIsSelectable(true);

        if (role == Message.Role.USER) {
            tv.setBackgroundResource(R.drawable.bg_user_message);
        } else {
            tv.setBackgroundResource(R.drawable.bg_ai_message);
        }

        LinearLayout.LayoutParams p =
                new LinearLayout.LayoutParams(-2, -2);
        p.setMargins(role == Message.Role.USER ? 64 : 0, 5,
                role == Message.Role.USER ? 0 : 64, 5);
        messagesContainer.addView(tv, p);

        if (animateUi) {
            tv.setAlpha(0f);
            tv.setTranslationY(12f);
            ObjectAnimator a = ObjectAnimator.ofFloat(tv, "alpha", 0f, 1f);
            a.setDuration(180);
            a.setInterpolator(new DecelerateInterpolator());
            a.addListener(new AnimatorListenerAdapter() {
                @Override public void onAnimationEnd(Animator animation) {
                    tv.setTranslationY(0f);
                }
            });
            a.start();

            ObjectAnimator y = ObjectAnimator.ofFloat(tv, "translationY", 12f, 0f);
            y.setDuration(180);
            y.setInterpolator(new DecelerateInterpolator());
            y.start();
        }

        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    @Override
    protected void onDestroy() {
        if (llm != null) llm.release();
        if (tts != null) tts.release();
        super.onDestroy();
    }
}
