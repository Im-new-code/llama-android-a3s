package com.jarvis.local;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.jarvis.local.ai.LlmEngine;
import com.jarvis.local.ai.PlaceholderLlmEngine;
import com.jarvis.local.core.ConversationManager;
import com.jarvis.local.core.Message;
import com.jarvis.local.ui.GlowOrbView;
import com.jarvis.local.ui.VoiceVisualizerView;
import com.jarvis.local.voice.SentenceQueue;
import com.jarvis.local.voice.TtsManager;

import java.util.List;

public final class MainActivity extends Activity {
    private static final int COMPOSE_REQUEST = 4201;
    private LinearLayout messagesContainer;
    private ScrollView scroll;
    private EditText input;
    private TextView status;
    private VoiceVisualizerView visualizer;
    private GlowOrbView orb;
    private ConversationManager conversation;
    private LlmEngine llm;
    private TtsManager tts;

    private final int bg = Color.rgb(7, 9, 14);
    private final int text = Color.rgb(244, 247, 251);
    private final int muted = Color.rgb(145, 157, 178);
    private final int accent = Color.rgb(107, 231, 255);
    private final int surface = Color.rgb(16, 21, 30);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        conversation = new ConversationManager();
        llm = new PlaceholderLlmEngine();
        tts = new TtsManager(this);
        buildUi();
    }

    private TextView label(String value, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        return tv;
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private ImageButton iconButton(int drawableId, String description, View.OnClickListener listener) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawableId);
        b.setContentDescription(description);
        b.setBackgroundResource(R.drawable.bg_icon_button);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        b.setColorFilter(Color.WHITE);
        b.setOnClickListener(listener);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(16), dp(10), dp(16), dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        orb = new GlowOrbView(this);
        header.addView(orb, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);

        TextView title = label("JARVIS", 22, text);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleBox.addView(title);

        status = label("LOCAL  •  READY", 11, muted);
        titleBox.addView(status);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        ImageButton settings = iconButton(R.drawable.ic_settings, "Settings", v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(dp(50), dp(50));
        settingsLp.setMargins(dp(4), dp(2), 0, dp(2));
        header.addView(settings, settingsLp);
        root.addView(header);

        LinearLayout subtitleRow = new LinearLayout(this);
        subtitleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView line = label("Private local assistant", 12, muted);
        subtitleRow.addView(line, new LinearLayout.LayoutParams(0, -2, 1));
        TextView local = label("NO CLOUD", 9, accent);
        local.setGravity(Gravity.CENTER);
        local.setBackgroundResource(R.drawable.bg_status_pill);
        local.setPadding(dp(9), dp(5), dp(9), dp(5));
        subtitleRow.addView(local);
        subtitleRow.setPadding(dp(5), dp(2), dp(2), dp(10));
        root.addView(subtitleRow);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setPadding(0, dp(5), 0, dp(12));
        scroll.addView(messagesContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        visualizer = new VoiceVisualizerView(this);
        visualizer.setVisibility(View.GONE);
        LinearLayout.LayoutParams visualLp = new LinearLayout.LayoutParams(-1, dp(44));
        visualLp.setMargins(dp(2), dp(3), dp(2), dp(2));
        root.addView(visualizer, visualLp);

        LinearLayout inputShell = new LinearLayout(this);
        inputShell.setGravity(Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        inputShell.setBackgroundResource(R.drawable.bg_input_shell);
        inputShell.setPadding(dp(5), dp(5), dp(5), dp(5));

        ImageButton expand = iconButton(R.drawable.ic_expand, "Full screen message editor", v -> openComposer());
        inputShell.addView(expand, new LinearLayout.LayoutParams(dp(46), dp(46)));

        input = new EditText(this);
        input.setTextColor(text);
        input.setHintTextColor(muted);
        input.setHint("Message JARVIS…");
        input.setTextSize(15);
        input.setSingleLine(false);
        input.setMinLines(1);
        input.setMaxLines(6);
        input.setGravity(Gravity.TOP | Gravity.CENTER_VERTICAL);
        input.setPadding(dp(7), dp(5), dp(7), dp(5));
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setVerticalScrollBarEnabled(false);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, -2, 1);
        inputLp.setMargins(dp(2), 0, dp(2), 0);
        inputShell.addView(input, inputLp);

        ImageButton send = iconButton(R.drawable.ic_send, "Send message", v -> sendMessage());
        inputShell.addView(send, new LinearLayout.LayoutParams(dp(46), dp(46)));
        root.addView(inputShell, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = label("Enter to send  •  Expand for longer messages", 9, muted);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(5), 0, 0);
        root.addView(hint);

        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { input.requestLayout(); }
            public void afterTextChanged(Editable e) {}
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (event != null && event.getKeyCode() == android.view.KeyEvent.KEYCODE_ENTER
                    && event.getAction() == android.view.KeyEvent.ACTION_DOWN) {
                sendMessage(); return true;
            }
            return false;
        });

        setContentView(root);
        addMessage(Message.Role.ASSISTANT,
                "Good to see you. I am JARVIS.\n\nThe interface is online. "
                        + "My local model bridge is the next component to connect.");
    }

    private void openComposer() {
        Intent i = new Intent(this, ComposeActivity.class);
        i.putExtra("draft", input.getText().toString());
        startActivityForResult(i, COMPOSE_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == COMPOSE_REQUEST && resultCode == RESULT_OK && data != null) {
            String value = data.getStringExtra("message");
            if (value != null) { input.setText(value); input.setSelection(value.length()); sendMessage(); }
        }
    }

    private void sendMessage() {
        String userText = input.getText().toString().trim();
        if (userText.isEmpty()) return;
        input.setText("");
        conversation.addUser(userText);
        addMessage(Message.Role.USER, userText);
        status.setText("LOCAL  •  THINKING");

        llm.generate(userText, new LlmEngine.Callback() {
            public void onToken(String token) {}
            public void onComplete(String fullText) {
                conversation.addAssistant(fullText);
                addMessage(Message.Role.ASSISTANT, fullText);
                status.setText("LOCAL  •  READY");
                if (getPreferences(MODE_PRIVATE).getBoolean("auto_speak", false)) speakText(fullText);
            }
            public void onError(Throwable error) {
                status.setText("LOCAL  •  ERROR");
                addMessage(Message.Role.ASSISTANT, "I hit a local error: " + error.getMessage());
            }
        });
    }

    private void speakText(String body) {
        List<String> queue = SentenceQueue.split(body);
        if (queue.isEmpty()) return;
        visualizer.setVisibility(View.VISIBLE);
        visualizer.startAnimating();
        orb.setSpeaking(true);
        status.setText("LOCAL  •  SPEAKING");
        tts.speakQueue(queue, new TtsManager.Callback() {
            public void onStarted(String sentence) {}
            public void onSentenceDone(String sentence) {}
            public void onAllDone() { stopSpeakingVisuals(); }
            public void onError(Throwable error) { stopSpeakingVisuals(); Toast.makeText(MainActivity.this, "TTS is not connected yet", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void stopSpeakingVisuals() {
        runOnUiThread(() -> {
            visualizer.stopAnimating();
            visualizer.setVisibility(View.GONE);
            orb.setSpeaking(false);
            status.setText("LOCAL  •  READY");
        });
    }

    private void addMessage(Message.Role role, String body) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(role == Message.Role.USER ? Gravity.END : Gravity.START);

        LinearLayout bubbleColumn = new LinearLayout(this);
        bubbleColumn.setOrientation(LinearLayout.VERTICAL);
        bubbleColumn.setGravity(role == Message.Role.USER ? Gravity.END : Gravity.START);

        TextView tv = label(body, 15, text);
        tv.setPadding(dp(15), dp(12), dp(15), dp(12));
        tv.setTextIsSelectable(true);
        tv.setBackgroundResource(role == Message.Role.USER ? R.drawable.bg_user_message : R.drawable.bg_ai_message);
        tv.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels * 0.84f));
        tv.setOnLongClickListener(v -> { showMessageMenu(tv, body); return true; });
        bubbleColumn.addView(tv, new LinearLayout.LayoutParams(-2, -2));

        TextView more = label("•••", 12, muted);
        more.setGravity(Gravity.CENTER);
        more.setPadding(dp(10), dp(2), dp(10), dp(3));
        more.setOnClickListener(v -> showMessageMenu(tv, body));
        bubbleColumn.addView(more, new LinearLayout.LayoutParams(-2, dp(27)));

        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(-2, -2);
        if (role == Message.Role.USER) colLp.setMargins(dp(42), dp(4), 0, dp(2));
        else colLp.setMargins(0, dp(4), dp(42), dp(2));
        row.addView(bubbleColumn, colLp);
        messagesContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));

        boolean animations = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("animations", true);
        if (animations) {
            row.setAlpha(0f); row.setTranslationY(dp(7));
            ObjectAnimator a = ObjectAnimator.ofFloat(row, "alpha", 0f, 1f); a.setDuration(180); a.start();
            ObjectAnimator y = ObjectAnimator.ofFloat(row, "translationY", dp(7), 0f); y.setDuration(180); y.start();
        }
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void showMessageMenu(View anchor, String body) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Copy");
        menu.getMenu().add("Speak");
        menu.getMenu().add("Share");
        menu.getMenu().add("Select text");
        menu.setOnMenuItemClickListener(item -> {
            String action = item.getTitle().toString();
            if (action.equals("Copy")) {
                ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("JARVIS message", body));
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
            } else if (action.equals("Speak")) {
                speakText(body);
            } else if (action.equals("Share")) {
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("text/plain");
                share.putExtra(Intent.EXTRA_TEXT, body);
                startActivity(Intent.createChooser(share, "Share JARVIS message"));
            } else if (action.equals("Select text")) {
                if (anchor instanceof TextView) ((TextView)anchor).setTextIsSelectable(true);
                Toast.makeText(this, "Long press or select the text", Toast.LENGTH_SHORT).show();
            }
            return true;
        });
        menu.show();
    }

    @Override protected void onDestroy() {
        if (llm != null) llm.release();
        if (tts != null) tts.release();
        super.onDestroy();
    }
}
