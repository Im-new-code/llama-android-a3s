package com.jarvis.local;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.jarvis.local.ai.LlmEngine;
import com.jarvis.local.ai.PlaceholderLlmEngine;
import com.jarvis.local.core.CalculatorEngine;
import com.jarvis.local.core.ConversationManager;
import com.jarvis.local.core.Message;
import com.jarvis.local.core.MusicManager;
import com.jarvis.local.ui.GlowOrbView;
import com.jarvis.local.ui.VoiceVisualizerView;
import com.jarvis.local.voice.SentenceQueue;
import com.jarvis.local.voice.TtsManager;

import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int COMPOSE_REQUEST = 4201;
    private LinearLayout messagesContainer;
    private ScrollView scroll;
    private EditText input;
    private TextView status;
    private VoiceVisualizerView visualizer;
    private GlowOrbView orb;
    private ConversationManager conversation;
    private LlmEngine llm;
    private TtsManager tts;
    private MusicManager music;

    private final int bg = Color.rgb(7, 9, 14);
    private final int text = Color.rgb(244, 247, 251);
    private final int muted = Color.rgb(145, 157, 178);

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        conversation = new ConversationManager();
        llm = new PlaceholderLlmEngine();
        tts = new TtsManager(this);
        music = new MusicManager(this);
        buildUi();
    }

    private TextView label(String value, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(value); tv.setTextSize(size); tv.setTextColor(color);
        return tv;
    }

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private ImageButton iconButton(int drawableId, String description, View.OnClickListener listener) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(drawableId);
        b.setContentDescription(description);
        b.setBackgroundResource(R.drawable.bg_icon_button);
        b.setPadding(dp(10), dp(10), dp(10), dp(10));
        b.setOnClickListener(listener);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(16), dp(10), dp(16), dp(8));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        orb = new GlowOrbView(this);
        header.addView(orb, new LinearLayout.LayoutParams(dp(56), dp(56)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);
        TextView title = label("JARVIS", 22, text);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleBox.addView(title);
        status = label("LOCAL  •  READY", 11, muted);
        titleBox.addView(status);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        ImageButton settings = iconButton(R.drawable.ic_settings, "Settings", v ->
                startActivity(new Intent(this, SettingsActivity.class)));
        LinearLayout.LayoutParams settingsLp = new LinearLayout.LayoutParams(dp(52), dp(52));
        settingsLp.setMargins(dp(2), 0, 0, 0);
        header.addView(settings, settingsLp);
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(58)));

        LinearLayout subtitleRow = new LinearLayout(this);
        subtitleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView line = label("Private local assistant", 12, muted);
        subtitleRow.addView(line, new LinearLayout.LayoutParams(0, -2, 1));
        TextView local = label("NO CLOUD", 9, Color.rgb(107, 231, 255));
        local.setGravity(Gravity.CENTER);
        local.setBackgroundResource(R.drawable.bg_status_pill);
        local.setPadding(dp(9), dp(5), dp(9), dp(5));
        subtitleRow.addView(local);
        subtitleRow.setPadding(dp(5), dp(2), dp(2), dp(7));
        root.addView(subtitleRow);

        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setFocusable(false);
        messagesContainer = new LinearLayout(this);
        messagesContainer.setOrientation(LinearLayout.VERTICAL);
        messagesContainer.setPadding(0, dp(5), 0, dp(18));
        scroll.addView(messagesContainer);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        visualizer = new VoiceVisualizerView(this);
        visualizer.setVisibility(View.GONE);
        LinearLayout.LayoutParams visualLp = new LinearLayout.LayoutParams(-1, dp(38));
        visualLp.setMargins(dp(2), dp(2), dp(2), dp(1));
        root.addView(visualizer, visualLp);

        LinearLayout inputShell = new LinearLayout(this);
        inputShell.setGravity(Gravity.CENTER_VERTICAL);
        inputShell.setBackgroundResource(R.drawable.bg_input_shell);
        inputShell.setPadding(dp(5), dp(5), dp(5), dp(5));

        ImageButton expand = iconButton(R.drawable.ic_expand, "Full screen message editor", v -> openComposer());
        inputShell.addView(expand, new LinearLayout.LayoutParams(dp(44), dp(44)));

        input = new EditText(this);
        input.setTextColor(text);
        input.setHintTextColor(muted);
        input.setHint("Message JARVIS…");
        input.setTextSize(15);
        input.setSingleLine(false);
        input.setMinLines(1);
        input.setMaxLines(6);
        input.setMinHeight(dp(44));
        input.setMaxHeight(dp(132));
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(7), dp(4), dp(7), dp(4));
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setVerticalScrollBarEnabled(false);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, -2, 1);
        inputLp.setMargins(dp(2), 0, dp(2), 0);
        inputShell.addView(input, inputLp);

        ImageButton send = iconButton(R.drawable.ic_send, "Send message", v -> sendMessage());
        inputShell.addView(send, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(inputShell, new LinearLayout.LayoutParams(-1, -2));

        TextView hint = label("Enter to send  •  Expand for longer messages", 9, muted);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(5), 0, 0);
        root.addView(hint);

        input.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int before, int count) {
                input.setGravity(input.getLineCount() > 1 ? Gravity.TOP : Gravity.CENTER_VERTICAL);
            }
            public void afterTextChanged(Editable e) {}
        });
        input.setOnEditorActionListener((v, actionId, event) -> {
            if (event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN && !event.isShiftPressed()) {
                sendMessage(); return true;
            }
            return false;
        });

        setContentView(root);
        addMessage(Message.Role.ASSISTANT,
                "Good to see you. I am JARVIS.\n\nThe interface is online. My local model bridge is the next component to connect.", null);
        input.requestFocus();
        input.postDelayed(() -> {
            InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
        }, 180);
    }

    private void openComposer() {
        Intent i = new Intent(this, ComposeActivity.class);
        i.putExtra("draft", input.getText().toString());
        startActivityForResult(i, COMPOSE_REQUEST);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == COMPOSE_REQUEST && resultCode == RESULT_OK && data != null) {
            String value = data.getStringExtra("message");
            if (value != null && !value.trim().isEmpty()) {
                input.setText(value);
                input.setSelection(value.length());
                sendMessage();
            }
        }
        if (input != null) input.requestFocus();
    }

    private void sendMessage() {
        String userText = input.getText().toString().trim();
        if (userText.isEmpty()) return;

        input.setText("");
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.requestFocus();

        conversation.addUser(userText);
        addMessage(Message.Role.USER, userText, null);
        status.setText("LOCAL  •  THINKING");
        scrollToBottomSoon();

        String lower = userText.toLowerCase(Locale.ROOT);
        if (handleImmediateCommand(lower, userText)) {
            input.requestFocus();
            return;
        }

        String calculation = CalculatorEngine.tryCalculate(userText);
        if (calculation != null) {
            deliverAssistant(calculation, userText);
            return;
        }

        llm.generate(userText, new LlmEngine.Callback() {
            public void onToken(String token) {}
            public void onComplete(String fullText) { deliverAssistant(fullText, userText); }
            public void onError(Throwable error) {
                status.setText("LOCAL  •  ERROR");
                addMessage(Message.Role.ASSISTANT, "I hit a local error: " + error.getMessage(), userText);
                input.requestFocus();
            }
        });
    }

    private boolean handleImmediateCommand(String lower, String original) {
        if (lower.equals("stop") || lower.equals("stop speaking") || lower.equals("stop talking") || lower.equals("be quiet")) {
            tts.stop();
            stopSpeakingVisuals();
            music.stop();
            deliverAssistant("Stopped.", original);
            return true;
        }
        if (lower.equals("stop music") || lower.equals("pause music") || lower.equals("pause the music")) {
            music.pause();
            deliverAssistant("Music paused.", original);
            return true;
        }
        if (lower.equals("resume music") || lower.equals("continue music")) {
            music.resume();
            deliverAssistant("Music resumed.", original);
            return true;
        }
        if (lower.startsWith("play music") || lower.startsWith("play song") || lower.startsWith("play ")) {
            String query = "";
            if (lower.startsWith("play music")) query = original.substring(Math.min(original.length(), 10)).trim();
            else if (lower.startsWith("play song")) query = original.substring(Math.min(original.length(), 9)).trim();
            else query = original.substring(Math.min(original.length(), 5)).trim();
            if (!hasMusicPermission()) {
                deliverAssistant("Local music access is disabled. Enable Read only music library in Settings first.", original);
            } else {
                status.setText("LOCAL  •  MUSIC");
                music.play(query, message -> runOnUiThread(() -> deliverAssistant(message, original)));
            }
            return true;
        }
        return false;
    }

    private boolean hasMusicPermission() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? "android.permission.READ_MEDIA_AUDIO"
                : "android.permission.READ_EXTERNAL_STORAGE";
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
    }

    private void deliverAssistant(String fullText, String originalPrompt) {
        conversation.addAssistant(fullText);
        addMessage(Message.Role.ASSISTANT, fullText, originalPrompt);
        status.setText("LOCAL  •  READY");
        if (getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("auto_speak", false)) speakText(fullText);
        input.requestFocus();
        scrollToBottomSoon();
    }

    private void retry(String originalPrompt) {
        if (originalPrompt == null || originalPrompt.trim().isEmpty()) return;
        status.setText("LOCAL  •  REGENERATING");
        llm.generate(originalPrompt, new LlmEngine.Callback() {
            public void onToken(String token) {}
            public void onComplete(String fullText) { deliverAssistant(fullText, originalPrompt); }
            public void onError(Throwable error) {
                status.setText("LOCAL  •  ERROR");
                Toast.makeText(MainActivity.this, "Could not regenerate", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void speakText(String body) {
        List<String> queue = SentenceQueue.split(body);
        if (queue.isEmpty()) return;
        visualizer.setVisibility(View.VISIBLE);
        visualizer.startAnimating();
        orb.setSpeaking(true);
        status.setText("LOCAL  •  SPEAKING");
        tts.speakQueue(queue, new TtsManager.Callback() {
            public void onStarted(String sentence) {}
            public void onSentenceDone(String sentence) {}
            public void onAllDone() { stopSpeakingVisuals(); }
            public void onError(Throwable error) { stopSpeakingVisuals(); Toast.makeText(MainActivity.this, "TTS is not connected yet", Toast.LENGTH_SHORT).show(); }
        });
    }

    private void stopSpeakingVisuals() {
        runOnUiThread(() -> {
            visualizer.stopAnimating();
            visualizer.setVisibility(View.GONE);
            orb.setSpeaking(false);
            status.setText("LOCAL  •  READY");
        });
    }

    private void addMessage(Message.Role role, String body, String retryPrompt) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(role == Message.Role.USER ? Gravity.END : Gravity.START);

        LinearLayout bubbleColumn = new LinearLayout(this);
        bubbleColumn.setOrientation(LinearLayout.VERTICAL);
        bubbleColumn.setGravity(role == Message.Role.USER ? Gravity.END : Gravity.START);

        TextView tv = label(body, 15, text);
        tv.setPadding(dp(15), dp(12), dp(15), dp(12));
        tv.setTextIsSelectable(true);
        tv.setBackgroundResource(role == Message.Role.USER ? R.drawable.bg_user_message : R.drawable.bg_ai_message);
        tv.setMaxWidth((int)(getResources().getDisplayMetrics().widthPixels * 0.84f));
        bubbleColumn.addView(tv, new LinearLayout.LayoutParams(-2, -2));

        if (role == Message.Role.ASSISTANT) {
            LinearLayout actions = new LinearLayout(this);
            actions.setOrientation(LinearLayout.HORIZONTAL);
            actions.setGravity(Gravity.START);
            actions.setPadding(0, dp(3), 0, 0);
            addAction(actions, R.drawable.ic_copy, "Copy", () -> copyText(body));
            addAction(actions, R.drawable.ic_volume, "Speak", () -> speakText(body));
            addAction(actions, R.drawable.ic_share, "Share", () -> shareText(body));
            if (retryPrompt != null) addAction(actions, R.drawable.ic_retry, "Retry", () -> retry(retryPrompt));
            bubbleColumn.addView(actions, new LinearLayout.LayoutParams(-1, dp(30)));
        } else {
            tv.setOnLongClickListener(v -> {
                showUserMessageMenu(tv, body);
                return true;
            });
            tv.setContentDescription("Your message. Long press for message options.");
        }

        LinearLayout.LayoutParams colLp = new LinearLayout.LayoutParams(-2, -2);
        colLp.gravity = role == Message.Role.USER ? Gravity.END : Gravity.START;
        boolean compact = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("compact", false);
        int vertical = compact ? 2 : 5;
        if (role == Message.Role.USER) colLp.setMargins(dp(38), dp(vertical), 0, dp(2));
        else colLp.setMargins(0, dp(vertical), dp(38), dp(2));
        row.addView(bubbleColumn, colLp);
        messagesContainer.addView(row, new LinearLayout.LayoutParams(-1, -2));

        boolean animations = getSharedPreferences("jarvis", MODE_PRIVATE).getBoolean("animations", true);
        if (animations) {
            row.setAlpha(0f); row.setTranslationY(dp(6));
            row.animate().alpha(1f).translationY(0f).setDuration(170).start();
        }
        scrollToBottomSoon();
    }

    private void addAction(LinearLayout actions, int icon, String description, Runnable action) {
        ImageButton b = new ImageButton(this);
        b.setImageResource(icon);
        b.setContentDescription(description);
        b.setBackgroundResource(R.drawable.bg_action_button);
        b.setPadding(dp(5), dp(5), dp(5), dp(5));
        b.setOnClickListener(v -> action.run());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(30), dp(30));
        lp.setMargins(0, 0, dp(5), 0);
        actions.addView(b, lp);
    }

    private void showUserMessageMenu(View anchor, String body) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenu().add("Copy");
        menu.getMenu().add("Share");
        menu.getMenu().add("Select text");
        menu.setOnMenuItemClickListener(item -> {
            String title = item.getTitle().toString();
            if (title.equals("Copy")) copyText(body);
            else if (title.equals("Share")) shareText(body);
            else if (title.equals("Select text")) {
                if (anchor instanceof TextView) ((TextView) anchor).setTextIsSelectable(true);
            }
            return true;
        });
        menu.show();
    }

    private void copyText(String body) {
        ClipboardManager cm = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("JARVIS message", body));
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show();
    }

    private void shareText(String body) {
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_TEXT, body);
        startActivity(Intent.createChooser(share, "Share JARVIS message"));
    }

    private void scrollToBottomSoon() {
        if (scroll == null || messagesContainer == null) return;
        scroll.post(() -> scroll.smoothScrollTo(0, Math.max(0, messagesContainer.getMeasuredHeight())));
    }

    @Override protected void onDestroy() {
        if (llm != null) llm.release();
        if (tts != null) tts.release();
        if (music != null) music.release();
        super.onDestroy();
    }
}
