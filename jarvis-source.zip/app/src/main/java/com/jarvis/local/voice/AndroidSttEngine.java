package com.jarvis.local.voice;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import com.jarvis.local.core.DebugLog;

import java.util.ArrayList;
import java.util.Locale;

/** Android SpeechRecognizer wrapper. Requests offline recognition where the installed provider supports it. */
public final class AndroidSttEngine implements SttEngine {
    private final Context context;
    private SpeechRecognizer recognizer;
    private volatile boolean listening;
    private volatile Callback callback;

    public AndroidSttEngine(Context context) {
        this.context = context.getApplicationContext();
        DebugLog.init(this.context);
    }

    @Override public boolean isReady() {
        return SpeechRecognizer.isRecognitionAvailable(context);
    }

    @Override public void start(Callback cb) {
        if (!isReady()) {
            if (cb != null) cb.onError(new IllegalStateException("No Android speech recognition service is available"));
            return;
        }
        callback = cb;
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(context);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) {
                    listening = true;
                }
                @Override public void onBeginningOfSpeech() {}
                @Override public void onRmsChanged(float rmsdB) {}
                @Override public void onBufferReceived(byte[] buffer) {}
                @Override public void onEndOfSpeech() {
                    listening = false;
                }
                @Override public void onError(int error) {
                    listening = false;
                    Callback c = callback;
                    if (c != null) c.onError(new IllegalStateException(errorName(error)));
                }
                @Override public void onResults(Bundle results) {
                    listening = false;
                    String text = firstResult(results);
                    Callback c = callback;
                    if (c != null && !text.isEmpty()) c.onFinal(text);
                }
                @Override public void onPartialResults(Bundle partialResults) {
                    String text = firstResult(partialResults);
                    Callback c = callback;
                    if (c != null && !text.isEmpty()) c.onPartial(text);
                }
                @Override public void onEvent(int eventType, Bundle params) {}
            });
        }
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.US.toLanguageTag());
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, Locale.US.toLanguageTag());
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            intent.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true);
            recognizer.startListening(intent);
            DebugLog.write(context, "STT listening started (offline preferred)");
        } catch (Throwable e) {
            listening = false;
            if (callback != null) callback.onError(e);
        }
    }

    @Override public void stop() {
        listening = false;
        if (recognizer != null) {
            try { recognizer.stopListening(); } catch (Throwable ignored) {}
            try { recognizer.cancel(); } catch (Throwable ignored) {}
        }
    }

    @Override public void release() {
        listening = false;
        if (recognizer != null) {
            try { recognizer.cancel(); } catch (Throwable ignored) {}
            try { recognizer.destroy(); } catch (Throwable ignored) {}
            recognizer = null;
        }
        callback = null;
    }

    public boolean isListening() { return listening; }

    private static String firstResult(Bundle bundle) {
        if (bundle == null) return "";
        ArrayList<String> list = bundle.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (list == null || list.isEmpty() || list.get(0) == null) return "";
        return list.get(0).trim();
    }

    private static String errorName(int code) {
        switch (code) {
            case SpeechRecognizer.ERROR_AUDIO: return "Audio recording error";
            case SpeechRecognizer.ERROR_CLIENT: return "Speech recognizer client error";
            case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS: return "Microphone permission denied";
            case SpeechRecognizer.ERROR_NETWORK: return "Speech recognizer network error";
            case SpeechRecognizer.ERROR_NETWORK_TIMEOUT: return "Speech recognizer network timeout";
            case SpeechRecognizer.ERROR_NO_MATCH: return "No speech recognized";
            case SpeechRecognizer.ERROR_RECOGNIZER_BUSY: return "Speech recognizer is busy";
            case SpeechRecognizer.ERROR_SERVER: return "Speech recognizer server error";
            case SpeechRecognizer.ERROR_SPEECH_TIMEOUT: return "Speech timeout";
            default: return "Speech recognition error " + code;
        }
    }
}
