package com.jarvis.local.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

public final class StartupBootView extends View {
    public enum Phase { BOOT, INITIALIZING, READY, ERROR }
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF arc = new RectF();
    private Phase phase = Phase.BOOT;
    private long start = System.currentTimeMillis();

    public StartupBootView(Context context) {
        super(context);
        p.setStrokeCap(Paint.Cap.ROUND);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public void setPhase(Phase value) { phase = value; invalidate(); }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        float cx = getWidth() * 0.5f;
        float cy = getHeight() * 0.45f;
        float base = Math.min(getWidth(), getHeight()) * 0.18f;
        long elapsed = System.currentTimeMillis() - start;
        float rot = (elapsed % 7000L) / 7000f * 360f;

        c.drawColor(Color.rgb(5,7,12));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f);
        p.setColor(Color.argb(35,107,231,255));
        c.drawCircle(cx, cy, base * 1.55f, p);
        c.drawCircle(cx, cy, base * 1.18f, p);

        p.setColor(Color.argb(90,107,231,255));
        p.setStrokeWidth(3f);
        arc.set(cx-base*1.45f, cy-base*1.45f, cx+base*1.45f, cy+base*1.45f);
        c.drawArc(arc, rot, 220f, false, p);
        p.setColor(Color.argb(130,138,125,255));
        arc.set(cx-base*1.28f, cy-base*1.28f, cx+base*1.28f, cy+base*1.28f);
        c.drawArc(arc, -rot*0.7f, 145f, false, p);

        p.setStyle(Paint.Style.FILL);
        p.setShadowLayer(base*0.45f, 0, 0, Color.argb(130,107,231,255));
        p.setColor(phase == Phase.ERROR ? Color.rgb(230,90,100) : Color.rgb(107,231,255));
        c.drawCircle(cx, cy, base*0.34f, p);
        p.clearShadowLayer();
        p.setColor(Color.argb(180,244,247,251));
        c.drawCircle(cx, cy, base*0.11f, p);

        p.setTextAlign(Paint.Align.CENTER);
        p.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.BOLD));
        p.setTextSize(base*0.36f);
        p.setColor(Color.rgb(244,247,251));
        c.drawText("JARVIS", cx, cy + base*2.05f, p);
        p.setTypeface(android.graphics.Typeface.create("sans", android.graphics.Typeface.NORMAL));
        p.setTextSize(base*0.17f);
        p.setColor(Color.rgb(145,157,178));
        String state = phase == Phase.READY ? "SYSTEMS ONLINE" : phase == Phase.ERROR ? "INITIALIZATION FAILED" : "INITIALIZING LOCAL SYSTEMS";
        c.drawText(state, cx, cy + base*2.48f, p);
        postInvalidateDelayed(32);
    }
}
