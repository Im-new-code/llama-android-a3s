package com.jarvis.local.ai;

import com.jarvis.local.core.Message;
import java.util.List;

/** Retained only as a harmless fallback class for source compatibility. */
public final class PlaceholderLlmEngine implements LlmEngine {
    @Override public boolean isReady() { return false; }
    @Override public void generate(String userText, List<Message> history, Callback callback) {
        if (callback != null) callback.onError(new IllegalStateException("No local model engine configured."));
    }
    @Override public void stop() {}
    @Override public void release() {}
}
