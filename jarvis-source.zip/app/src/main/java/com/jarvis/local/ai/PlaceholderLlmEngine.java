package com.jarvis.local.ai;

import android.os.Handler;
import android.os.Looper;

public final class PlaceholderLlmEngine implements LlmEngine {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean stopped;

    @Override
    public boolean isReady() {
        return true;
    }

    @Override
    public void generate(String userText, Callback callback) {
        stopped = false;
        handler.postDelayed(() -> {
            if (stopped) return;
            String reply = "JARVIS is ready, but the local language model bridge is not connected yet. "
                    + "The application shell, conversation layer and voice pipeline are prepared for it.";
            callback.onComplete(reply);
        }, 180);
    }

    @Override
    public void stop() {
        stopped = true;
        handler.removeCallbacksAndMessages(null);
    }

    @Override
    public void release() {
        stop();
    }
}
