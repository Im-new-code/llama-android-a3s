package com.jarvis.local.voice;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class TtsManager {

    public interface Callback {
        void onStarted(String sentence);
        void onSentenceDone(String sentence);
        void onAllDone();
        void onError(Throwable error);
    }

    private final Context context;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private AudioTrack audioTrack;
    private volatile boolean stopped = false;

    // Expected external model directory on the target phone.
    private final File modelDirectory;

    public TtsManager(Context context) {
        this.context = context.getApplicationContext();
        modelDirectory = new File(
                "/storage/emulated/0/AI-Models/vits-piper-en_US-hfc_male-medium"
        );
    }

    public boolean modelDirectoryExists() {
        return modelDirectory.isDirectory();
    }

    public File getModelDirectory() {
        return modelDirectory;
    }

    /*
     * The actual Sherpa ONNX JNI implementation is intentionally isolated.
     *
     * This project ships the Android UI/audio architecture without bundling
     * a 63 MB speech model. The build workflow adds the Sherpa AAR, while
     * the Piper model stays in user storage.
     */
    public void speak(String text, Callback callback) {
        stopped = false;
        executor.execute(() -> {
            try {
                if (!modelDirectoryExists()) {
                    throw new IllegalStateException(
                            "HFC Male Piper model not found at " + modelDirectory.getAbsolutePath()
                    );
                }

                main.post(() -> callback.onStarted(text));

                /*
                 * The generated PCM should eventually be received directly
                 * from OfflineTts and streamed into AudioTrack here.
                 *
                 * The method below is kept separate so the real Sherpa
                 * implementation can replace only this function.
                 */
                File generated = new File(context.getCacheDir(), "jarvis_tts_pcm.wav");

                // No fake audio is emitted. Callers get a clear error until
                // Sherpa generation is connected.
                throw new UnsupportedOperationException(
                        "Sherpa ONNX generation bridge is awaiting integration."
                );

            } catch (Throwable error) {
                main.post(() -> callback.onError(error));
            }
        });
    }

    public void speakQueue(java.util.List<String> sentences, Callback callback) {
        stopped = false;
        executor.execute(() -> {
            try {
                for (String sentence : sentences) {
                    if (stopped) {
                        return;
                    }
                    main.post(() -> callback.onStarted(sentence));

                    // Placeholder boundary. The native Sherpa generation and
                    // AudioTrack streaming will be inserted here.
                    throw new UnsupportedOperationException(
                            "Sherpa ONNX queue bridge is awaiting integration."
                    );
                }
                main.post(callback::onAllDone);
            } catch (Throwable error) {
                main.post(() -> callback.onError(error));
            }
        });
    }

    public void stop() {
        stopped = true;
        executor.shutdownNow();
        if (audioTrack != null) {
            try {
                audioTrack.pause();
                audioTrack.flush();
                audioTrack.release();
            } catch (Throwable ignored) {
            }
            audioTrack = null;
        }
    }

    public void release() {
        stop();
    }

    /*
     * Utility for the future direct PCM path.
     */
    public static void playPcm16Mono(Context context, short[] samples, int sampleRate) {
        int min = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
        );
        AudioTrack track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(Math.max(min, samples.length * 2))
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build();

        ByteBuffer buffer = ByteBuffer.allocate(samples.length * 2)
                .order(ByteOrder.LITTLE_ENDIAN);
        for (short sample : samples) buffer.putShort(sample);
        buffer.flip();

        track.write(buffer.array(), 0, buffer.remaining());
        track.play();
    }

    public static void closeQuietly(FileInputStream in) {
        try {
            if (in != null) in.close();
        } catch (IOException ignored) {
        }
    }
}
