package com.jarvis.local.voice;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.os.Handler;
import android.os.Looper;

import com.jarvis.local.core.DebugLog;
import com.jarvis.local.core.StoragePathResolver;
import com.k2fsa.sherpa.onnx.GeneratedAudio;
import com.k2fsa.sherpa.onnx.GenerationConfig;
import com.k2fsa.sherpa.onnx.OfflineTts;
import com.k2fsa.sherpa.onnx.OfflineTtsConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsVitsModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsMatchaModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsKokoroModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsZipVoiceModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsKittenModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsPocketModelConfig;
import com.k2fsa.sherpa.onnx.OfflineTtsSupertonicModelConfig;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Persistent offline HFC Male TTS. The expensive Sherpa engine is kept warm between responses. */
public final class TtsManager {
    public interface Callback {
        void onStarted(String sentence);
        void onSentenceDone(String sentence);
        void onAllDone();
        void onError(Throwable error);
    }

    private static final class AudioItem {
        final String sentence;
        final float[] samples;
        final int sampleRate;
        AudioItem(String sentence, float[] samples, int sampleRate) {
            this.sentence = sentence;
            this.samples = samples;
            this.sampleRate = sampleRate;
        }
    }

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService control = Executors.newSingleThreadExecutor();
    private volatile AudioTrack audioTrack;
    private volatile OfflineTts tts;
    private volatile File loadedModelDir;
    private volatile boolean stopped;
    private volatile Thread queueThread;
    private volatile Thread playbackThread;

    public TtsManager(Context context) {
        this.context = context.getApplicationContext();
        DebugLog.init(this.context);
    }

    public File getModelDirectory() {
        return StoragePathResolver.findHfcMaleDirectory(context);
    }

    public boolean modelDirectoryExists() {
        return getModelDirectory() != null;
    }

    public String modelLabel() {
        File dir = getModelDirectory();
        return dir == null ? "HFC Male model not found" : dir.getAbsolutePath();
    }

    public static void rememberModelDirectory(Context context, File dir) {
        DebugLog.write(context, "Ignoring alternate TTS path; JARVIS uses the fixed device voice model location");
    }

    public interface PreloadCallback {
        void onStarted();
        void onComplete();
        void onError(Throwable error);
    }

    public void preload(PreloadCallback callback) {
        stopped = false;
        control.execute(() -> {
            if (callback != null) main.post(callback::onStarted);
            try {
                File dir = StoragePathResolver.fixedHfcMaleDirectory();
                if (dir == null) throw new IllegalStateException("HFC Male model not found at the fixed model location");
                getOrCreateEngine(dir);
                if (callback != null) main.post(callback::onComplete);
            } catch (Throwable e) {
                postError(null, e);
                if (callback != null) main.post(() -> callback.onError(e));
            }
        });
    }

    public void speakQueue(List<String> sentences, Callback callback) {
        stopInternal(false);
        if (sentences == null || sentences.isEmpty()) {
            if (callback != null) main.post(callback::onAllDone);
            return;
        }
        List<String> clean = new ArrayList<>();
        for (String s : sentences) {
            if (s != null && !s.trim().isEmpty()) clean.add(s.trim());
        }
        if (clean.isEmpty()) {
            if (callback != null) main.post(callback::onAllDone);
            return;
        }

        stopped = false;
        control.execute(() -> {
            queueThread = Thread.currentThread();
            try {
                runQueue(clean, callback);
            } finally {
                queueThread = null;
            }
        });
    }

    public void speak(String text, Callback callback) {
        speakQueue(SentenceQueue.split(text), callback);
    }

    private void runQueue(List<String> sentences, Callback callback) {
        File dir = getModelDirectory();
        if (dir == null) {
            postError(callback, new IllegalStateException("HFC Male Piper model not found. Place it at /storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models/vits-piper-en_US-hfc_male-medium."));
            return;
        }

        try {
            long queueStart = System.nanoTime();
            DebugLog.write(context, "TTS queue start count=" + sentences.size() + ", model=" + dir.getAbsolutePath());

            OfflineTts engine = getOrCreateEngine(dir);
            if (engine == null) throw new IllegalStateException("Could not initialize the HFC Male TTS engine");

            BlockingQueue<Object> queue = new ArrayBlockingQueue<>(2);
            final Object END = new Object();

            Thread playback = new Thread(() -> {
                playbackThread = Thread.currentThread();
                try {
                    while (!stopped) {
                        Object next = queue.take();
                        if (next == END) break;
                        AudioItem item = (AudioItem) next;
                        main.post(() -> {
                            if (!stopped && callback != null) callback.onStarted(item.sentence);
                        });
                        play(item.samples, item.sampleRate);
                        main.post(() -> {
                            if (!stopped && callback != null) callback.onSentenceDone(item.sentence);
                        });
                    }
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                } catch (Throwable e) {
                    if (!stopped) postError(callback, e);
                } finally {
                    playbackThread = null;
                }
            }, "JARVIS-TTS-Playback");
            playback.start();

            for (String sentence : sentences) {
                if (stopped) break;
                long genStart = System.nanoTime();
                GeneratedAudio audio = generate(engine, sentence);
                long genMs = (System.nanoTime() - genStart) / 1_000_000L;
                if (stopped) break;
                if (audio == null || audio.getSamples() == null || audio.getSamples().length == 0) {
                    throw new IllegalStateException("Sherpa returned empty audio");
                }
                queue.put(new AudioItem(sentence, audio.getSamples(), audio.getSampleRate()));
                DebugLog.write(context, "TTS generated chars=" + sentence.length() + ", samples=" + audio.getSamples().length + ", genMs=" + genMs);
            }

            if (!stopped) queue.put(END);
            playback.join();
            long ms = (System.nanoTime() - queueStart) / 1_000_000L;
            DebugLog.write(context, "TTS queue finish elapsedMs=" + ms);
            if (!stopped && callback != null) main.post(callback::onAllDone);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (!stopped) postError(callback, e);
        } catch (Throwable error) {
            if (!stopped) postError(callback, error);
        }
    }

    private synchronized OfflineTts getOrCreateEngine(File dir) {
        if (tts != null && loadedModelDir != null
                && loadedModelDir.getAbsolutePath().equals(dir.getAbsolutePath())) {
            DebugLog.write(context, "TTS engine reused speed=" + getSpeed());
            return tts;
        }

        releaseEngine();
        long start = System.nanoTime();
        OfflineTts engine = createEngine(dir);
        long ms = (System.nanoTime() - start) / 1_000_000L;
        tts = engine;
        loadedModelDir = dir;
        DebugLog.write(context, "TTS engine loaded elapsedMs=" + ms + ", lengthScale=0.90, noiseScale=0.667, noiseScaleW=0.80, threads=" + getThreadCount() + ", speed=" + getSpeed());
        return engine;
    }

    private OfflineTts createEngine(File dir) {
        OfflineTtsVitsModelConfig vits = new OfflineTtsVitsModelConfig(
                new File(dir, "en_US-hfc_male-medium.onnx").getAbsolutePath(),
                "",
                new File(dir, "tokens.txt").getAbsolutePath(),
                new File(dir, "espeak-ng-data").getAbsolutePath(),
                "",
                0.667f,
                0.80f,
                0.90f
        );
        OfflineTtsMatchaModelConfig matcha = new OfflineTtsMatchaModelConfig("", "", "", "", "", "", 1.0f, 1.0f);
        OfflineTtsKokoroModelConfig kokoro = new OfflineTtsKokoroModelConfig("", "", "", "", "", "", "", 1.0f);
        OfflineTtsZipVoiceModelConfig zipVoice = new OfflineTtsZipVoiceModelConfig("", "", "", "", "", "", 0.1f, 0.5f, 0.1f, 1.0f);
        OfflineTtsKittenModelConfig kitten = new OfflineTtsKittenModelConfig("", "", "", "", 1.0f);
        OfflineTtsPocketModelConfig pocket = new OfflineTtsPocketModelConfig("", "", "", "", "", "", "", 50);
        OfflineTtsSupertonicModelConfig supertonic = new OfflineTtsSupertonicModelConfig("", "", "", "", "", "", "");
        OfflineTtsModelConfig model = new OfflineTtsModelConfig(
                vits, matcha, kokoro, zipVoice, kitten, pocket, supertonic,
                getThreadCount(), DebugLog.verboseNative(context), "cpu"
        );
        OfflineTtsConfig config = new OfflineTtsConfig(model, "", "", 1, 0.2f);
        return new OfflineTts(null, config);
    }

    private int getThreadCount() {
        return context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getBoolean("tts_threads4", true) ? 4 : 2;
    }

    private GeneratedAudio generate(OfflineTts engine, String sentence) {
        float speed = getSpeed();
        GenerationConfig config = new GenerationConfig(0.2f, speed, 0, null, 0, null, 5, null);
        return engine.generateWithConfig(sentence, config);
    }

    private float getSpeed() {
        int value = context.getSharedPreferences("jarvis", Context.MODE_PRIVATE).getInt("tts_speed", 20);
        return Math.max(0.7f, Math.min(1.3f, 0.80f + value * 0.01f));
    }

    private void play(float[] samples, int sampleRate) {
        if (stopped) return;
        int min = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
        int chunk = 2048;
        int bytes = Math.max(min, chunk * 2);
        AudioTrack track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setSampleRate(sampleRate)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build())
                .setBufferSizeInBytes(bytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build();
        audioTrack = track;
        try {
            track.play();
            short[] pcm = new short[chunk];
            int pos = 0;
            while (pos < samples.length && !stopped) {
                int count = Math.min(chunk, samples.length - pos);
                for (int i = 0; i < count; i++) {
                    float v = Math.max(-1f, Math.min(1f, samples[pos + i]));
                    pcm[i] = (short) Math.round(v * 32767f);
                }
                track.write(pcm, 0, count);
                pos += count;
            }
        } finally {
            try { track.stop(); } catch (Throwable ignored) {}
            try { track.release(); } catch (Throwable ignored) {}
            if (audioTrack == track) audioTrack = null;
        }
    }

    private void postError(Callback callback, Throwable e) {
        DebugLog.write(context, "TTS error=" + e.getClass().getSimpleName() + ": " + e.getMessage());
        if (callback != null) main.post(() -> callback.onError(e));
    }

    private void stopInternal(boolean shutdown) {
        stopped = true;
        Thread worker = queueThread;
        if (worker != null) worker.interrupt();
        Thread playback = playbackThread;
        if (playback != null) playback.interrupt();

        AudioTrack track = audioTrack;
        if (track != null) {
            try { track.pause(); } catch (Throwable ignored) {}
            try { track.flush(); } catch (Throwable ignored) {}
            try { track.stop(); } catch (Throwable ignored) {}
        }

        if (shutdown) {
            control.shutdownNow();
            // The control thread owns native generation. Do not release the engine here.
        }
    }

    private synchronized void releaseEngine() {
        OfflineTts engine = tts;
        tts = null;
        loadedModelDir = null;
        if (engine != null) {
            try { engine.release(); } catch (Throwable ignored) {}
        }
    }

    public void stop() {
        stopInternal(false);
    }

    public void release() {
        stopped = true;
        Thread worker = queueThread;
        if (worker != null) worker.interrupt();
        Thread playback = playbackThread;
        if (playback != null) playback.interrupt();
        AudioTrack track = audioTrack;
        if (track != null) {
            try { track.pause(); } catch (Throwable ignored) {}
            try { track.flush(); } catch (Throwable ignored) {}
            try { track.stop(); } catch (Throwable ignored) {}
        }
        if (worker == null) releaseEngine();
        control.shutdownNow();
    }
}
