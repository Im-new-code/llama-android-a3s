package com.jarvis.local.core;

import android.content.Context;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small optional diagnostic log. Enabled by default. */
public final class DebugLog {
    private static final String PREFS = "jarvis";
    private static final String FILE_NAME = "jarvis-debug.log";
    private static final Object LOCK = new Object();

    private DebugLog() {}

    public static boolean enabled(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean("debug_logging", false);
    }

    public static boolean verboseNative(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean("debug_verbose_native", false);
    }

    public static File logFile(Context context) {
        File dir = new File(context.getExternalFilesDir(null), "logs");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, FILE_NAME);
    }

    public static void init(Context context) {
        if (!enabled(context)) return;
        File f = logFile(context);
        if (f.length() == 0) {
            write(context, "JARVIS session started");
            write(context, "App version 0.5.0");
            write(context, "Device " + Build.MANUFACTURER + " " + Build.MODEL + ", Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")");
            write(context, "ABI " + Build.SUPPORTED_ABIS[0]);
        }
    }

    public static void write(Context context, String message) {
        if (!enabled(context) || message == null) return;
        String stamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(new Date());
        synchronized (LOCK) {
            try (FileOutputStream out = new FileOutputStream(logFile(context), true)) {
                out.write(("[" + stamp + "] " + message.replace('\n', ' ') + "\n").getBytes(StandardCharsets.UTF_8));
            } catch (Exception ignored) {
            }
        }
    }

    public static String read(Context context) {
        try {
            File f = logFile(context);
            if (!f.isFile()) return "";
            return new String(java.nio.file.Files.readAllBytes(f.toPath()), StandardCharsets.UTF_8);
        } catch (Exception e) {
            return "Could not read log: " + e.getMessage();
        }
    }

    public static void clear(Context context) {
        File f = logFile(context);
        if (f.isFile()) f.delete();
        init(context);
    }
}
