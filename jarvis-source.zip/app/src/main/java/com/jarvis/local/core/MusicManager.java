package com.jarvis.local.core;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.provider.MediaStore;

/** Read only local music access. Playback uses MediaStore content URIs. */
public final class MusicManager {
    public interface Callback {
        void onStatus(String status);
    }

    private final Context context;
    private MediaPlayer player;
    private String currentTitle;

    public MusicManager(Context context) {
        this.context = context.getApplicationContext();
    }

    public boolean isPlaying() {
        return player != null && player.isPlaying();
    }

    public String getCurrentTitle() {
        return currentTitle;
    }

    public void play(String query, Callback callback) {
        stopInternal();
        MediaTrack track = findTrack(query);
        if (track == null) {
            if (callback != null) callback.onStatus("I could not find a local music track.");
            return;
        }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build());
            player.setDataSource(context, track.uri);
            player.setOnPreparedListener(mp -> {
                currentTitle = track.title;
                mp.start();
                if (callback != null) callback.onStatus("Playing " + track.title + ".");
            });
            player.setOnCompletionListener(mp -> {
                currentTitle = null;
                stopInternal();
                if (callback != null) callback.onStatus("Music finished.");
            });
            player.prepareAsync();
        } catch (Throwable error) {
            stopInternal();
            if (callback != null) callback.onStatus("I could not play that track.");
        }
    }

    public void pause() {
        if (player != null && player.isPlaying()) player.pause();
    }

    public void resume() {
        if (player != null) player.start();
    }

    public void stop() {
        stopInternal();
    }

    public void release() {
        stopInternal();
    }

    private void stopInternal() {
        if (player != null) {
            try { player.stop(); } catch (Throwable ignored) {}
            try { player.release(); } catch (Throwable ignored) {}
            player = null;
        }
        currentTitle = null;
    }

    private MediaTrack findTrack(String query) {
        ContentResolver resolver = context.getContentResolver();
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.IS_MUSIC
        };
        String selection = MediaStore.Audio.Media.IS_MUSIC + " != 0";
        String[] args = null;
        String cleaned = query == null ? "" : query.trim();
        if (!cleaned.isEmpty()) {
            selection += " AND (" + MediaStore.Audio.Media.TITLE + " LIKE ? OR "
                    + MediaStore.Audio.Media.ARTIST + " LIKE ?)";
            String q = "%" + cleaned.replace("%", "") + "%";
            args = new String[] { q, q };
        }
        try (Cursor c = resolver.query(uri, projection, selection, args,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c == null || !c.moveToFirst()) return null;
            long id = c.getLong(c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
            String title = c.getString(c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE));
            return new MediaTrack(Uri.withAppendedPath(uri, String.valueOf(id)), title);
        }
    }

    private static final class MediaTrack {
        final Uri uri;
        final String title;
        MediaTrack(Uri uri, String title) { this.uri = uri; this.title = title; }
    }
}
