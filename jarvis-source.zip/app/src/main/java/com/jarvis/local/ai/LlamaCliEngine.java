package com.jarvis.local.ai;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.jarvis.local.core.DebugLog;
import com.jarvis.local.core.Message;
import com.jarvis.local.core.StoragePathResolver;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class LlamaCliEngine implements LlmEngine {
    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile Process process;
    private volatile boolean stopped;

    public LlamaCliEngine(Context context) {
        this.context = context.getApplicationContext();
        DebugLog.init(this.context);
    }

    public static File modelFile(Context context) {
        return StoragePathResolver.findSmolModel(context);
    }

    public static boolean hasModel(Context context) {
        File f = modelFile(context);
        return f != null && f.isFile() && f.length() > 0;
    }

    public static String modelLabel(Context context) {
        File f = modelFile(context);
        return hasModel(context)
                ? f.getAbsolutePath() + "  •  " + (f.length() / (1024 * 1024)) + " MB"
                : "No SmolLM2 GGUF found on accessible storage";
    }

    public static void rememberModel(Context context, File model) {
        DebugLog.write(context, "Ignoring alternate LLM path; JARVIS uses the fixed device model location");
    }

    private File bundledCli() {
        return new File(context.getFilesDir(), "llama-cli");
    }

    private File bundledCliLibDir() {
        return new File(context.getFilesDir(), "llama-libs");
    }

    private synchronized void ensureNativeRuntime() throws Exception {
        File dir = bundledCliLibDir();
        if (!dir.exists() && !dir.mkdirs()) {
            throw new IllegalStateException("Could not create local Llama runtime directory");
        }

        String[] assets;
        try {
            assets = context.getAssets().list("llama-libs");
        } catch (Exception e) {
            throw new IllegalStateException("Bundled Llama native libraries are missing", e);
        }
        if (assets == null || assets.length == 0) {
            throw new IllegalStateException("Bundled Llama native libraries are missing");
        }

        byte[] buffer = new byte[64 * 1024];
        boolean hasLlama = false;
        for (String name : assets) {
            if (name == null || !name.endsWith(".so")) continue;
            if ("libllama.so".equals(name)) hasLlama = true;
            File target = new File(dir, name);
            if (target.isFile() && target.length() > 0) continue;

            File temp = new File(dir, name + ".tmp");
            try (java.io.InputStream in = context.getAssets().open("llama-libs/" + name);
                 OutputStream out = new FileOutputStream(temp)) {
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                out.flush();
            }
            if (target.exists() && !target.delete()) {
                temp.delete();
                throw new IllegalStateException("Could not replace native library " + name);
            }
            if (!temp.renameTo(target)) {
                temp.delete();
                throw new IllegalStateException("Could not install native library " + name);
            }
            target.setReadable(true, false);
        }

        if (!hasLlama || !new File(dir, "libllama.so").isFile()) {
            throw new IllegalStateException("Bundled libllama.so is missing");
        }
    }

    private void ensureCli() throws Exception {
        ensureNativeRuntime();
        File cli = bundledCli();
        if (cli.isFile() && cli.length() > 100000) {
            cli.setExecutable(true, false);
            return;
        }
        File temp = new File(context.getFilesDir(), "llama-cli.tmp");
        try (java.io.InputStream in = context.getAssets().open("llama-cli");
             OutputStream out = new FileOutputStream(temp)) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
        if (cli.exists()) cli.delete();
        if (!temp.renameTo(cli)) {
            try (FileInputStream in = new FileInputStream(temp); OutputStream out = new FileOutputStream(cli)) {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            temp.delete();
        }
        if (!cli.setExecutable(true, false)) throw new IllegalStateException("Could not make llama-cli executable");
    }

    @Override public boolean isReady() {
        return hasModel(context);
    }

    @Override public void preload(PreloadCallback callback) {
        stopped = false;
        executor.execute(() -> {
            if (callback != null) main.post(callback::onStarted);
            try {
                ensureCli();
                File model = modelFile(context);
                if (model == null || !model.isFile()) throw new IllegalStateException("SmolLM2 GGUF not found at the fixed model location");
                long start = System.nanoTime();
                List<String> command = new ArrayList<>();
                command.add(bundledCli().getAbsolutePath());
                command.add("-m"); command.add(model.getAbsolutePath());
                command.add("-c"); command.add("512");
                command.add("-n"); command.add("1");
                command.add("-t"); command.add("4");
                command.add("--jinja");
                command.add("--single-turn");
                command.add("--no-display-prompt");
                command.add("--color"); command.add("off");
                command.add("--temp"); command.add("0");
                command.add("-p"); command.add("Say ready.");
                ProcessBuilder pb = new ProcessBuilder(command);
                String oldLoader = pb.environment().get("LD_LIBRARY_PATH");
                String libPath = bundledCliLibDir().getAbsolutePath();
                pb.environment().put("LD_LIBRARY_PATH", oldLoader == null || oldLoader.isEmpty()
                        ? libPath : libPath + ":" + oldLoader);
                pb.redirectErrorStream(true);
                Process warm = pb.start();
                warm.getOutputStream().close();
                StringBuilder warmOutput = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(warm.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        if (warmOutput.length() < 4000) warmOutput.append(line).append('\n');
                    }
                }
                int exit = warm.waitFor();
                long ms = (System.nanoTime() - start) / 1_000_000L;
                DebugLog.write(context, "LLM preload complete model=" + model.getAbsolutePath() + ", elapsedMs=" + ms + ", exit=" + exit);
                if (exit != 0) {
                    String detail = warmOutput.toString().trim();
                    if (!detail.isEmpty() && DebugLog.verboseNative(context)) {
                        DebugLog.write(context, "LLM preload output=" + detail);
                    }
                    throw new IllegalStateException("Local model preload failed (code " + exit + ")");
                }
                if (callback != null) main.post(callback::onComplete);
            } catch (Throwable e) {
                DebugLog.write(context, "LLM preload error=" + e.getClass().getSimpleName() + ": " + e.getMessage());
                if (callback != null) main.post(() -> callback.onError(e));
            }
        });
    }

    @Override public void generate(String userText, List<Message> history, Callback callback) {
        stopped = false;
        executor.execute(() -> {
            try {
                ensureCli();
                File model = modelFile(context);
                if (model == null || !model.isFile()) throw new IllegalStateException("SmolLM2 GGUF not found at the fixed device model location.");

                String prompt = buildPrompt(userText, history);
                List<String> command = new ArrayList<>();
                command.add(bundledCli().getAbsolutePath());
                command.add("-m"); command.add(model.getAbsolutePath());
                command.add("-c"); command.add("1024");
                command.add("-n"); command.add("160");
                command.add("-t"); command.add("4");
                command.add("--jinja");
                command.add("--single-turn");
                command.add("--no-display-prompt");
                command.add("--color"); command.add("off");
                command.add("--no-show-timings");
                command.add("--temp"); command.add("0.7");
                command.add("--top-p"); command.add("0.9");
                command.add("--system-prompt");
                command.add("You are JARVIS, a concise, helpful private local AI assistant. Answer naturally and directly. Maintain continuity with the conversation provided. Do not mention being a small model unless relevant.");
                command.add("-p"); command.add(prompt);

                DebugLog.write(context, "LLM start model=" + model.getAbsolutePath() + ", promptChars=" + prompt.length());
                long start = System.nanoTime();
                ProcessBuilder pb = new ProcessBuilder(command);
                String oldLoader = pb.environment().get("LD_LIBRARY_PATH");
                String libPath = bundledCliLibDir().getAbsolutePath();
                pb.environment().put("LD_LIBRARY_PATH", oldLoader == null || oldLoader.isEmpty()
                        ? libPath : libPath + ":" + oldLoader);
                pb.redirectErrorStream(false);
                process = pb.start();
                process.getOutputStream().close();

                Thread stderr = new Thread(() -> {
                    try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getErrorStream(), StandardCharsets.UTF_8))) {
                        String line;
                        while ((line = r.readLine()) != null) {
                            if (DebugLog.verboseNative(context)) DebugLog.write(context, "llama: " + line);
                        }
                    } catch (Exception ignored) {}
                });
                stderr.start();

                StringBuilder response = new StringBuilder();
                try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = r.readLine()) != null) {
                        if (stopped) break;
                        if (line.trim().isEmpty()) continue;
                        if (response.length() > 0) response.append('\n');
                        response.append(line);
                        String token = line;
                        main.post(() -> { if (!stopped && callback != null) callback.onToken(token); });
                    }
                }
                int exit = process.waitFor();
                process = null;
                if (stopped) return;
                String answer = cleanResponse(response.toString());
                long ms = (System.nanoTime() - start) / 1_000_000L;
                DebugLog.write(context, "LLM finish exit=" + exit + ", chars=" + answer.length() + ", elapsedMs=" + ms);
                if (exit != 0 || answer.isEmpty()) throw new IllegalStateException("Local model exited without a response (code " + exit + ")");
                main.post(() -> callback.onComplete(answer));
            } catch (Throwable t) {
                process = null;
                DebugLog.write(context, "LLM error=" + t.getClass().getSimpleName() + ": " + t.getMessage());
                if (!stopped) main.post(() -> callback.onError(t));
            }
        });
    }

    private String buildPrompt(String current, List<Message> history) {
        StringBuilder b = new StringBuilder();
        b.append("Conversation so far:\n");
        if (history != null) {
            int start = Math.max(0, history.size() - 8);
            for (int i = start; i < history.size(); i++) {
                Message m = history.get(i);
                if (m == null || m.getText() == null) continue;
                if (i == history.size() - 1 && m.getRole() == Message.Role.USER
                        && m.getText().trim().equals(current == null ? "" : current.trim())) continue;
                String label = m.getRole() == Message.Role.USER ? "User" : "JARVIS";
                String text = m.getText().trim();
                if (text.length() > 900) text = text.substring(0, 900) + "…";
                b.append(label).append(": ").append(text).append('\n');
            }
        }
        b.append("\nAnswer the latest user message. Do not restate the conversation history.\n");
        b.append("User: ").append(current == null ? "" : current.trim());
        return b.toString();
    }

    private String cleanResponse(String text) {
        String s = text.replace("\r", "").trim();
        int marker = s.lastIndexOf("<|im_start|>assistant");
        if (marker >= 0) s = s.substring(marker + "<|im_start|>assistant".length()).trim();
        int end = s.indexOf("<|im_end|>");
        if (end >= 0) s = s.substring(0, end).trim();
        if (s.startsWith("assistant")) s = s.substring("assistant".length()).trim();
        if (s.startsWith("<think>") && s.contains("</think>")) s = s.substring(s.indexOf("</think>") + 8).trim();
        return s;
    }

    @Override public void stop() {
        stopped = true;
        Process p = process;
        if (p != null) p.destroy();
    }

    @Override public void release() {
        stop();
        executor.shutdownNow();
    }
}
