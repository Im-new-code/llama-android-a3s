package com.jarvis.local.ai;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import com.jarvis.local.core.DebugLog;
import com.jarvis.local.core.Message;
import com.jarvis.local.core.StoragePathResolver;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Persistent local llama.cpp runtime.
 *
 * A single llama-server process is started during JARVIS startup and kept alive
 * so the selected GGUF stays loaded. Chat requests are sent to localhost over
 * the server's OpenAI-compatible HTTP API.
 */
public final class LlamaCliEngine implements LlmEngine {
    private static final int PORT = 38765;
    private static final int CONTEXT = 1024;
    private static final int THREADS = 4;

    private final Context context;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Object stateLock = new Object();

    private volatile Process process;
    private volatile boolean stopped;
    private volatile boolean ready;
    private volatile String loadedModelPath;
    private volatile String lastServerOutput = "";

    public LlamaCliEngine(Context context) {
        this.context = context.getApplicationContext();
        DebugLog.init(this.context);
    }

    public static File modelFile(Context context) {
        return StoragePathResolver.findSmolModel(context);
    }

    public static boolean hasModel(Context context) {
        File f = modelFile(context);
        return f != null && f.isFile() && f.length() > 0;
    }

    public static String modelLabel(Context context) {
        File f = modelFile(context);
        return hasModel(context)
                ? f.getName() + "  •  " + (f.length() / (1024 * 1024)) + " MB"
                : "No GGUF model selected";
    }

    public static String modelPathLabel(Context context) {
        File f = modelFile(context);
        return hasModel(context) ? f.getAbsolutePath() : "No local GGUF model selected";
    }

    public static void rememberModel(Context context, File model) {
        if (model == null) return;
        StoragePathResolver.setSelectedLlmModel(context, model);
        DebugLog.write(context, "Selected LLM model=" + model.getAbsolutePath());
    }

    private File bundledServer() {
        return new File(context.getFilesDir(), "llama-server");
    }

    private File bundledServerLibDir() {
        return new File(context.getFilesDir(), "llama-libs");
    }

    private synchronized void ensureNativeRuntime() throws Exception {
        File dir = bundledServerLibDir();
        if (!dir.isDirectory() && !dir.mkdirs()) {
            throw new IllegalStateException("Could not create bundled Llama library directory");
        }

        String[] names = context.getAssets().list("llama-libs");
        if (names == null || names.length == 0) {
            throw new IllegalStateException("Bundled Llama native libraries are missing from the APK");
        }
        for (String name : names) {
            if (name != null && name.endsWith(".so")) {
                File required = new File(dir, name);
                if (!required.isFile() || required.length() == 0) {
                    extractOneLibrary(name, required);
                }
            }
        }
        for (String name : names) {
            if (name != null && name.endsWith(".so")) {
                File required = new File(dir, name);
                if (!required.isFile() || required.length() == 0) {
                    throw new IllegalStateException("Bundled Llama native library is missing: " + name);
                }
            }
        }
    }

    private void extractOneLibrary(String name, File outFile) throws Exception {
        byte[] buffer = new byte[64 * 1024];
        try (InputStream in = context.getAssets().open("llama-libs/" + name);
             OutputStream out = new FileOutputStream(outFile)) {
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
    }

    private void ensureServer() throws Exception {
        ensureNativeRuntime();
        File server = bundledServer();
        if (server.isFile() && server.length() > 100000) {
            if (!server.canExecute()) server.setExecutable(true, false);
            if (!server.canExecute()) throw new IllegalStateException("Bundled llama-server is not executable");
            return;
        }

        File temp = new File(context.getFilesDir(), "llama-server.tmp");
        try (InputStream in = context.getAssets().open("llama-server");
             OutputStream out = new FileOutputStream(temp)) {
            byte[] buffer = new byte[64 * 1024];
            int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
        if (server.exists()) server.delete();
        if (!temp.renameTo(server)) {
            try (FileInputStream in = new FileInputStream(temp); OutputStream out = new FileOutputStream(server)) {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            }
            temp.delete();
        }
        if (!server.setExecutable(true, false) || !server.canExecute()) {
            throw new IllegalStateException("Could not make llama-server executable");
        }
    }

    @Override public boolean isReady() {
        return ready && process != null && process.isAlive();
    }

    public boolean isLoading() {
        return !ready && process != null && process.isAlive();
    }

    public String getLoadedModelPath() {
        return loadedModelPath;
    }

    @Override public void preload(PreloadCallback callback) {
        stopped = false;
        executor.execute(() -> {
            if (callback != null) main.post(callback::onStarted);
            try {
                ensureServer();
                File model = modelFile(context);
                if (model == null || !model.isFile() || model.length() == 0) {
                    throw new IllegalStateException("Selected GGUF model is unavailable");
                }
                startServer(model);
                if (callback != null) main.post(callback::onComplete);
            } catch (Throwable e) {
                ready = false;
                DebugLog.write(context, "LLM preload error=" + e.getClass().getSimpleName() + ": " + e.getMessage());
                if (callback != null) main.post(() -> callback.onError(e));
            }
        });
    }

    /** Stop the current server and preload the currently selected model. */
    public void reloadSelectedModel(PreloadCallback callback) {
        stopped = false;
        executor.execute(() -> {
            if (callback != null) main.post(callback::onStarted);
            try {
                stopServerInternal();
                ensureServer();
                File model = modelFile(context);
                if (model == null || !model.isFile() || model.length() == 0) {
                    throw new IllegalStateException("Selected GGUF model is unavailable");
                }
                startServer(model);
                if (callback != null) main.post(callback::onComplete);
            } catch (Throwable e) {
                ready = false;
                DebugLog.write(context, "LLM reload error=" + e.getClass().getSimpleName() + ": " + e.getMessage());
                if (callback != null) main.post(() -> callback.onError(e));
            }
        });
    }

    private void startServer(File model) throws Exception {
        synchronized (stateLock) {
            if (isReady() && model.getAbsolutePath().equals(loadedModelPath)) {
                DebugLog.write(context, "LLM already loaded model=" + model.getAbsolutePath());
                return;
            }
            stopServerInternal();

            java.util.ArrayList<String> command = new java.util.ArrayList<>();
            command.add(bundledServer().getAbsolutePath());
            command.add("--model"); command.add(model.getAbsolutePath());
            command.add("--ctx-size"); command.add(String.valueOf(CONTEXT));
            command.add("--threads"); command.add(String.valueOf(THREADS));
            command.add("--host"); command.add("127.0.0.1");
            command.add("--port"); command.add(String.valueOf(PORT));
            command.add("--jinja");
            command.add("--verbose");

            ProcessBuilder pb = new ProcessBuilder(command);
            String oldLoader = pb.environment().get("LD_LIBRARY_PATH");
            String libPath = bundledServerLibDir().getAbsolutePath();
            pb.environment().put("LD_LIBRARY_PATH", oldLoader == null || oldLoader.isEmpty()
                    ? libPath : libPath + ":" + oldLoader);
            pb.redirectErrorStream(true);
            process = pb.start();
            stopped = false;
            ready = false;
            loadedModelPath = null;

            Thread logThread = new Thread(() -> consumeServerLog(process), "jarvis-llama-server-log");
            logThread.setDaemon(true);
            logThread.start();
        }

        long start = System.nanoTime();
        DebugLog.write(context, "LLM server starting model=" + model.getAbsolutePath());
        waitForServerReady(model, start);
    }

    private void consumeServerLog(Process p) {
        StringBuilder recent = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String clean = line.trim();
                if (clean.isEmpty()) continue;
                if (recent.length() > 5000) recent.delete(0, recent.length() - 5000);
                recent.append(clean).append('\n');
                lastServerOutput = recent.toString();
                if (DebugLog.verboseNative(context)) DebugLog.write(context, "LLM server: " + clean);
            }
        } catch (Exception e) {
            if (DebugLog.verboseNative(context)) DebugLog.write(context, "LLM server log reader error=" + e.getMessage());
        }
    }

    private void waitForServerReady(File model, long startNanos) throws Exception {
        long deadline = System.currentTimeMillis() + 180000L;
        String lastHealth = "";
        while (System.currentTimeMillis() < deadline) {
            Process p = process;
            if (stopped) throw new IllegalStateException("LLM preload stopped");
            if (p == null || !p.isAlive()) {
                String detail = compact(lastServerOutput);
                throw new IllegalStateException("llama-server exited during model load" + (detail.isEmpty() ? "" : ": " + detail));
            }
            try {
                int code = healthCheck();
                lastHealth = String.valueOf(code);
                if (code == 200) {
                    ready = true;
                    loadedModelPath = model.getAbsolutePath();
                    long ms = (System.nanoTime() - startNanos) / 1_000_000L;
                    DebugLog.write(context, "LLM preload complete model=" + model.getAbsolutePath() + ", elapsedMs=" + ms + ", health=" + lastHealth);
                    return;
                }
            } catch (Exception ignored) {
            }
            Thread.sleep(250L);
        }
        throw new IllegalStateException("Timed out waiting for llama-server to load the model. Last health=" + lastHealth + (lastServerOutput.isEmpty() ? "" : "\n" + compact(lastServerOutput)));
    }

    private int healthCheck() throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL("http://127.0.0.1:" + PORT + "/health").openConnection();
        conn.setConnectTimeout(500);
        conn.setReadTimeout(500);
        conn.setRequestMethod("GET");
        try {
            return conn.getResponseCode();
        } finally {
            conn.disconnect();
        }
    }

    @Override public void generate(String userText, List<Message> history, Callback callback) {
        stopped = false;
        executor.execute(() -> {
            try {
                File selected = modelFile(context);
                if (selected == null || !selected.isFile()) {
                    throw new IllegalStateException("Selected local GGUF model is unavailable. Choose another model in Settings.");
                }
                if (!isReady() || loadedModelPath == null || !loadedModelPath.equals(selected.getAbsolutePath())) {
                    startServer(selected);
                }
                String body = buildChatRequest(userText, history);
                DebugLog.write(context, "LLM request model=" + selected.getAbsolutePath() + ", promptChars=" + (userText == null ? 0 : userText.length()));
                String response = postJson("http://127.0.0.1:" + PORT + "/v1/chat/completions", body);
                String answer = extractAnswer(response);
                if (answer.isEmpty()) throw new IllegalStateException("Local model returned an empty response");
                if (callback != null) main.post(() -> callback.onComplete(answer));
            } catch (Throwable t) {
                ready = false;
                DebugLog.write(context, "LLM error=" + t.getClass().getSimpleName() + ": " + t.getMessage());
                if (!stopped && callback != null) main.post(() -> callback.onError(t));
            }
        });
    }

    private String buildChatRequest(String current, List<Message> history) throws Exception {
        JSONObject root = new JSONObject();
        root.put("model", "local");
        root.put("stream", false);
        root.put("temperature", 0.2);
        root.put("max_tokens", 160);

        JSONArray messages = new JSONArray();
        JSONObject system = new JSONObject();
        system.put("role", "system");
        system.put("content", "You are JARVIS, a concise, helpful private local AI assistant. Answer naturally and directly. Maintain continuity with the conversation. Do not mention being a small model unless relevant.");
        messages.put(system);

        if (history != null) {
            int start = Math.max(0, history.size() - 8);
            for (int i = start; i < history.size(); i++) {
                Message m = history.get(i);
                if (m == null || m.getText() == null) continue;
                if (i == history.size() - 1 && m.getRole() == Message.Role.USER
                        && m.getText().trim().equals(current == null ? "" : current.trim())) continue;
                JSONObject message = new JSONObject();
                message.put("role", m.getRole() == Message.Role.USER ? "user" : "assistant");
                String text = m.getText().trim();
                if (text.length() > 900) text = text.substring(0, 900) + "…";
                message.put("content", text);
                messages.put(message);
            }
        }

        JSONObject latest = new JSONObject();
        latest.put("role", "user");
        latest.put("content", current == null ? "" : current.trim());
        messages.put(latest);
        root.put("messages", messages);
        return root.toString();
    }

    private String postJson(String endpoint, String json) throws Exception {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        conn.setConnectTimeout(3000);
        conn.setReadTimeout(180000);
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        conn.setFixedLengthStreamingMode(bytes.length);
        try (OutputStream out = conn.getOutputStream()) {
            out.write(bytes);
        }
        int code = conn.getResponseCode();
        InputStream stream = code >= 200 && code < 300 ? conn.getInputStream() : conn.getErrorStream();
        StringBuilder response = new StringBuilder();
        if (stream != null) {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                String line;
                while ((line = reader.readLine()) != null) response.append(line);
            }
        }
        conn.disconnect();
        if (code < 200 || code >= 300) {
            throw new IllegalStateException("llama-server HTTP " + code + ": " + compact(response.toString()));
        }
        return response.toString();
    }

    private String extractAnswer(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONArray choices = root.optJSONArray("choices");
        if (choices == null || choices.length() == 0) return "";
        JSONObject first = choices.getJSONObject(0);
        JSONObject message = first.optJSONObject("message");
        String answer = message == null ? first.optString("text", "") : message.optString("content", "");
        return cleanResponse(answer);
    }

    private String cleanResponse(String text) {
        String s = text == null ? "" : text.replace("\r", "").trim();
        int end = s.indexOf("<|im_end|>");
        if (end >= 0) s = s.substring(0, end).trim();
        if (s.startsWith("assistant")) s = s.substring("assistant".length()).trim();
        if (s.startsWith("<think>") && s.contains("</think>")) s = s.substring(s.indexOf("</think>") + 8).trim();
        return s;
    }

    private String compact(String value) {
        String s = value == null ? "" : value.replace('\n', ' ').replace('\r', ' ').trim();
        return s.length() > 800 ? s.substring(0, 800) + "…" : s;
    }

    @Override public void stop() {
        stopped = true;
        executor.execute(this::stopServerInternal);
    }

    private void stopServerInternal() {
        synchronized (stateLock) {
            ready = false;
            loadedModelPath = null;
            Process p = process;
            process = null;
            if (p != null) {
                try { p.destroy(); } catch (Exception ignored) {}
                try {
                    if (!p.waitFor(1500, java.util.concurrent.TimeUnit.MILLISECONDS)) p.destroyForcibly();
                } catch (Exception ignored) {
                    try { p.destroyForcibly(); } catch (Exception ignored2) {}
                }
            }
        }
    }

    @Override public void release() {
        stopped = true;
        stopServerInternal();
        executor.shutdownNow();
    }
}
