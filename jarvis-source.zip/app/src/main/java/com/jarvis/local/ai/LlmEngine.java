package com.jarvis.local.ai;

import com.jarvis.local.core.Message;

import java.util.List;

public interface LlmEngine {
    interface Callback {
        void onToken(String token);
        void onComplete(String fullText);
        void onError(Throwable error);
    }

    boolean isReady();

    void preload(PreloadCallback callback);

    interface PreloadCallback {
        void onStarted();
        void onComplete();
        void onError(Throwable error);
    }

    void generate(String userText, List<Message> history, Callback callback);

    void stop();

    void release();
}
