package com.jarvis.local.ai;

public interface LlmEngine {
    interface Callback {
        void onToken(String token);
        void onComplete(String fullText);
        void onError(Throwable error);
    }

    boolean isReady();

    void generate(String userText, Callback callback);

    void stop();

    void release();
}
