package com.jarvis.local.ai;

import com.jarvis.local.core.Message;

import java.util.List;

public interface LlmEngine {
    interface Callback {
        void onToken(String token);
        void onComplete(String fullText);
        void onError(Throwable error);
    }

    boolean isReady();

    void generate(String userText, List<Message> history, Callback callback);

    void stop();

    void release();
}
