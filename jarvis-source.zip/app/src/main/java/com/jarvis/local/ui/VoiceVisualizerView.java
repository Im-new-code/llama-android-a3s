package com.jarvis.local.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;
import java.util.Random;

public final class VoiceVisualizerView extends View {
    private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG); private final Random random=new Random(7); private ValueAnimator animator; private float phase;
    public VoiceVisualizerView(Context c){super(c);paint.setColor(0xFF6BE7FF);paint.setStrokeWidth(3f);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void startAnimating(){if(animator!=null&&animator.isRunning())return;animator=ValueAnimator.ofFloat(0f,1f);animator.setDuration(700);animator.setRepeatCount(ValueAnimator.INFINITE);animator.addUpdateListener(v->{phase=(float)v.getAnimatedValue();invalidate();});animator.start();}
    public void stopAnimating(){if(animator!=null){animator.cancel();animator=null;}invalidate();}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float cy=getHeight()/2f;int n=28;float gap=getWidth()/(float)(n+1);for(int i=0;i<n;i++){float x=(i+1)*gap;float wave=(float)Math.abs(Math.sin(phase*Math.PI*2+i*.63));float center=1f-Math.abs(i-(n-1)/2f)/((n-1)/2f);float h=getHeight()*(.12f+.72f*center*wave);c.drawRoundRect(x-1.6f,cy-h/2,x+1.6f,cy+h/2,2,2,paint);}}
}
