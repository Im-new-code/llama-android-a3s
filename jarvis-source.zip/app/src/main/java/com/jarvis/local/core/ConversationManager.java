package com.jarvis.local.core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ConversationManager {
    private final List<Message> messages = new ArrayList<>();

    public void addUser(String text) {
        messages.add(new Message(Message.Role.USER, text));
    }

    public void addAssistant(String text) {
        messages.add(new Message(Message.Role.ASSISTANT, text));
    }

    public List<Message> snapshot() {
        return Collections.unmodifiableList(new ArrayList<>(messages));
    }

    public void clear() {
        messages.clear();
    }
}
