package com.jarvis.local.core;

import java.text.DecimalFormat;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Lightweight deterministic calculator used before the language model. */
public final class CalculatorEngine {
    private static final Pattern PREFIX = Pattern.compile(
            "(?i)^(?:what is|calculate|calc|compute|how much is|solve)\\s+(.+?)[?]?$"
    );
    private static final Pattern BARE = Pattern.compile(
            "^[0-9+\\-*/().%^\\s×÷,]+$"
    );

    private CalculatorEngine() {}

    public static String tryCalculate(String input) {
        if (input == null) return null;
        String raw = input.trim();
        if (raw.length() > 160) return null;

        String expression = null;
        Matcher prefix = PREFIX.matcher(raw);
        if (prefix.matches()) expression = prefix.group(1);
        else if (BARE.matcher(raw).matches()) expression = raw;
        if (expression == null) return null;

        expression = expression.replace("×", "*").replace("÷", "/").replace(",", "").trim();
        if (expression.isEmpty()) return null;

        try {
            double value = new Parser(expression).parse();
            if (Double.isNaN(value) || Double.isInfinite(value)) return null;
            DecimalFormat format = new DecimalFormat("0.##########");
            String result = format.format(value);
            return "The answer is " + result + ".";
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static final class Parser {
        private final String s;
        private int pos;

        Parser(String s) { this.s = s; }

        double parse() {
            double value = expression();
            skipSpaces();
            if (pos != s.length()) throw new IllegalArgumentException();
            return value;
        }

        double expression() {
            double value = term();
            while (true) {
                skipSpaces();
                if (match('+')) value += term();
                else if (match('-')) value -= term();
                else return value;
            }
        }

        double term() {
            double value = power();
            while (true) {
                skipSpaces();
                if (match('*')) value *= power();
                else if (match('/')) {
                    double divisor = power();
                    if (Math.abs(divisor) < 1e-15) throw new ArithmeticException();
                    value /= divisor;
                } else return value;
            }
        }

        double power() {
            double base = unary();
            skipSpaces();
            if (match('^')) return Math.pow(base, power());
            return base;
        }

        double unary() {
            skipSpaces();
            if (match('+')) return unary();
            if (match('-')) return -unary();
            return postfix();
        }

        double postfix() {
            double value = primary();
            while (true) {
                skipSpaces();
                if (match('%')) value /= 100.0;
                else return value;
            }
        }

        double primary() {
            skipSpaces();
            if (match('(')) {
                double value = expression();
                if (!match(')')) throw new IllegalArgumentException();
                return value;
            }
            int start = pos;
            boolean dot = false;
            while (pos < s.length()) {
                char c = s.charAt(pos);
                if (Character.isDigit(c)) { pos++; continue; }
                if (c == '.' && !dot) { dot = true; pos++; continue; }
                break;
            }
            if (start == pos) throw new IllegalArgumentException();
            return Double.parseDouble(s.substring(start, pos));
        }

        boolean match(char expected) {
            skipSpaces();
            if (pos < s.length() && s.charAt(pos) == expected) {
                pos++;
                return true;
            }
            return false;
        }

        void skipSpaces() {
            while (pos < s.length() && Character.isWhitespace(s.charAt(pos))) pos++;
        }
    }
}
