package com.jarvis.local;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public final class SettingsActivity extends Activity {
    private final int bg=Color.rgb(7,9,14), text=Color.rgb(244,247,251), muted=Color.rgb(145,157,178), accent=Color.rgb(107,231,255);
    private SharedPreferences prefs; private int dp(float v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView make(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("jarvis",MODE_PRIVATE);
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(bg); LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(20),dp(18),dp(20),dp(24));scroll.addView(root);
        TextView top=make("JARVIS Settings",26,text);top.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(top);TextView sub=make("Tune the local experience without adding unnecessary overhead.",12,muted);sub.setPadding(0,dp(4),0,dp(18));root.addView(sub);
        addSection(root,"Appearance"); CheckBox animations=check("Light animations","Orb, message and speaking animations.");root.addView(animations);
        addSection(root,"Voice"); CheckBox autoSpeak=check("Speak responses automatically","Send completed responses to the local TTS queue.");root.addView(autoSpeak);
        CheckBox compact=check("Compact conversation","Reduce vertical spacing between messages.");root.addView(compact);
        addSection(root,"Performance"); CheckBox threads=check("Use four TTS worker threads","Recommended starting point for this device class.");root.addView(threads);
        addSection(root,"TTS tuning"); TextView speedLabel=make("Voice speed",14,text);root.addView(speedLabel);SeekBar speed=new SeekBar(this);speed.setMax(40);speed.setProgress(20);speed.setContentDescription("TTS speed");root.addView(speed);TextView range=make("HFC Male Piper target: length scale 0.90. Final speed control will connect during Sherpa integration.",11,muted);range.setPadding(0,0,0,dp(12));root.addView(range);
        addSection(root,"Models");TextView info=make("LLM  •  external GGUF\nTTS  •  en_US-hfc_male-medium\nSTT  •  Sherpa ONNX\nStorage  •  user controlled",13,muted);info.setBackgroundResource(R.drawable.bg_surface);info.setPadding(dp(16),dp(16),dp(16),dp(16));root.addView(info);
        addSection(root,"About"); TextView about=make("About JARVIS\nCreator links, source repository, issues and workflow shortcuts.",14,text);about.setBackgroundResource(R.drawable.bg_surface_soft);about.setPadding(dp(16),dp(14),dp(16),dp(14));about.setOnClickListener(v->startActivity(new Intent(this,AboutActivity.class)));root.addView(about);
        animations.setChecked(prefs.getBoolean("animations",true));autoSpeak.setChecked(prefs.getBoolean("auto_speak",false));compact.setChecked(prefs.getBoolean("compact",false));threads.setChecked(prefs.getBoolean("tts_threads4",true));
        animations.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean("animations",c).apply());autoSpeak.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean("auto_speak",c).apply());compact.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean("compact",c).apply());threads.setOnCheckedChangeListener((b,c)->prefs.edit().putBoolean("tts_threads4",c).apply());
        setContentView(scroll);
    }
    private void addSection(LinearLayout r,String s){TextView t=make(s.toUpperCase(),10,accent);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setPadding(dp(2),dp(16),dp(2),dp(7));r.addView(t);}
    private CheckBox check(String title,String summary){CheckBox b=new CheckBox(this);b.setText(title+"\n"+summary);b.setTextSize(14);b.setTextColor(text);b.setPadding(0,dp(5),0,dp(5));return b;}
}
