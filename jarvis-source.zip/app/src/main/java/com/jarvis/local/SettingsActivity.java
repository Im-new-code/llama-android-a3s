package com.jarvis.local;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import com.jarvis.local.ai.LlamaCliEngine;
import com.jarvis.local.core.DebugLog;
import com.jarvis.local.voice.TtsManager;

public final class SettingsActivity extends Activity {
    private static final int BG = Color.rgb(7, 9, 14);
    private static final int TEXT = Color.rgb(244, 247, 251);
    private static final int MUTED = Color.rgb(145, 157, 178);
    private static final int ACCENT = Color.rgb(107, 231, 255);
    private static final int MUSIC_PERMISSION_REQUEST = 7001;
    private static final int STORAGE_PERMISSION_REQUEST = 7002;
    private static final int LOG_EXPORT_REQUEST = 8103;
    private SharedPreferences prefs;
    private CheckBox musicAccess;
    private TextView musicStatus;

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView makeText(String value, float size, int color) {
        TextView view = new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color); return view;
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG); scroll.setFillViewport(true); scroll.setClipToPadding(false);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(14), dp(18), dp(34)); scroll.addView(root);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = makeText("‹", 34, TEXT); back.setGravity(Gravity.CENTER); back.setContentDescription("Back"); back.setBackgroundResource(R.drawable.bg_icon_button); back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titleBox = new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL); titleBox.setPadding(dp(12),0,0,0);
        TextView title = makeText("Settings", 23, TEXT); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD); titleBox.addView(title);
        titleBox.addView(makeText("Tune your private local experience.", 11, MUTED));
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1)); root.addView(top);

        addSection(root, "Appearance");
        CheckBox animations = check("Light animations", "Orb, message and speaking animations."); root.addView(animations);

        addSection(root, "Voice");
        CheckBox autoSpeak = check("Speak responses automatically", "Send completed responses to the local TTS queue."); root.addView(autoSpeak);

        CheckBox welcome = check("Startup welcome speech", "Play a short JARVIS greeting when the app starts."); root.addView(welcome);
        CheckBox welcomeVariation = check("Vary startup greetings", "Choose from the prepared JARVIS greeting set instead of repeating one line."); root.addView(welcomeVariation);
        CheckBox welcomePersonalized = check("Personalized future greetings", "Allow JARVIS to prepare a short contextual greeting for a later launch when the system is idle."); root.addView(welcomePersonalized);

        addSection(root, "Startup");
        CheckBox aiPreload = check("Preload local AI", "Initialize the local model during startup before the conversation opens."); root.addView(aiPreload);
        CheckBox ttsPreload = check("Preload voice engine", "Initialize HFC Male during startup so the first response does not pay the initialization cost."); root.addView(ttsPreload);

        addSection(root, "Conversation");
        CheckBox compact = check("Compact conversation", "Reduce vertical spacing between messages."); root.addView(compact);

        addSection(root, "Performance");
        CheckBox threads = check("Use four TTS worker threads", "Use four CPU threads for speech generation. Turn off for a lighter load."); root.addView(threads);

        addSection(root, "Local music");
        musicAccess = check("Read only music library", "Allow JARVIS to find and play music already stored on your phone. No music files are modified or uploaded.");
        root.addView(musicAccess);
        musicStatus = makeText("Checking permission…", 11, MUTED); musicStatus.setPadding(dp(3), 0, dp(3), dp(5)); root.addView(musicStatus);
        Button permissionButton = new Button(this); permissionButton.setText("Manage music permission"); permissionButton.setOnClickListener(v -> openPermissionSettings()); root.addView(permissionButton);

        addSection(root, "Calculator");
        CheckBox calculator = check("Use built in calculator", "Handle arithmetic locally instead of sending simple calculations to the language model."); root.addView(calculator);

        addSection(root, "TTS tuning");
        TextView speedLabel = makeText("Voice speed", 14, TEXT); root.addView(speedLabel);
        SeekBar speed = new SeekBar(this); speed.setMax(40); speed.setProgress(prefs.getInt("tts_speed", 20)); speed.setContentDescription("TTS speed");
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) { prefs.edit().putInt("tts_speed", progress).apply(); }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        }); root.addView(speed);
        TextView range = makeText("HFC Male Piper target: length scale 0.90. Speed is adjustable from 0.80× to 1.20×.", 11, MUTED); range.setPadding(0,dp(2),0,dp(8)); root.addView(range);

        addSection(root, "Local AI");
        TextView modelStatus = makeText("Model: " + LlamaCliEngine.modelLabel(this), 12, TEXT);
        modelStatus.setBackgroundResource(R.drawable.bg_surface);
        modelStatus.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.addView(modelStatus);
        TextView modelPath = makeText("Fixed device path:\n/storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models/SmolLM2-360M-Instruct-Q4_K_M.gguf", 11, MUTED);
        modelPath.setPadding(dp(3), 0, dp(3), dp(8));
        root.addView(modelPath);
        TextView modelNote = makeText("JARVIS uses the GGUF only from this fixed device path. It is never copied or downloaded by the app.", 11, MUTED);
        modelNote.setPadding(dp(3), 0, dp(3), dp(8));
        root.addView(modelNote);

        addSection(root, "Voice model");
        TtsManager ttsProbe = new TtsManager(this);
        TextView ttsStatus = makeText("HFC Male: " + ttsProbe.modelLabel(), 12, TEXT);
        ttsStatus.setBackgroundResource(R.drawable.bg_surface);
        ttsStatus.setPadding(dp(16), dp(14), dp(16), dp(14));
        root.addView(ttsStatus);
        TextView ttsPath = makeText("Fixed device path:\n/storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models/vits-piper-en_US-hfc_male-medium", 11, MUTED);
        ttsPath.setPadding(dp(3), 0, dp(3), dp(8));
        root.addView(ttsPath);
        TextView ttsNote = makeText("JARVIS is tuned for this device and uses the fixed HFC Male model path shown below. The model is read in place and is never copied.", 11, MUTED);
        ttsNote.setPadding(dp(3), 0, dp(3), dp(8));
        root.addView(ttsNote);
        ttsProbe.release();

        addSection(root, "Models");
        TextView info = makeText("LLM   •   SmolLM2 360M Q4_K_M\nTTS   •   en_US-hfc_male-medium\nSTT   •   Sherpa ONNX\nCalculator   •   local deterministic\nMusic   •   MediaStore read only", 13, MUTED);
        info.setBackgroundResource(R.drawable.bg_surface); info.setPadding(dp(16),dp(16),dp(16),dp(16)); root.addView(info);

        addSection(root, "Developer");
        CheckBox debug = check("Enable debug logging", "Keep detailed JARVIS diagnostics for troubleshooting. Enabled by default.");
        root.addView(debug);
        CheckBox verbose = check("Verbose engine diagnostics", "Record additional llama.cpp and Sherpa diagnostic information.");
        root.addView(verbose);
        Button exportLog = new Button(this);
        exportLog.setText("Export current debug log");
        exportLog.setOnClickListener(v -> exportLog());
        root.addView(exportLog);
        Button clearLog = new Button(this);
        clearLog.setText("Clear debug log");
        clearLog.setOnClickListener(v -> { DebugLog.clear(this); Toast.makeText(this, "Debug log cleared", Toast.LENGTH_SHORT).show(); });
        root.addView(clearLog);
        debug.setChecked(prefs.getBoolean("debug_logging", true));
        verbose.setChecked(prefs.getBoolean("debug_verbose_native", true));
        verbose.setEnabled(debug.isChecked());
        debug.setOnCheckedChangeListener((button, checked) -> {
            prefs.edit().putBoolean("debug_logging", checked).apply();
            verbose.setEnabled(checked);
            if (checked) DebugLog.init(this);
            DebugLog.write(this, "Debug logging " + (checked ? "enabled" : "disabled"));
        });
        verbose.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("debug_verbose_native", checked).apply());

        addSection(root, "About");
        TextView about = makeText("About JARVIS\nCreator, source code, issues and workflow shortcuts.", 14, TEXT);
        about.setBackgroundResource(R.drawable.bg_surface_soft); about.setPadding(dp(16),dp(14),dp(16),dp(14));
        about.setOnClickListener(v -> startActivity(new Intent(SettingsActivity.this, AboutActivity.class))); root.addView(about);

        animations.setChecked(prefs.getBoolean("animations", true));
        autoSpeak.setChecked(prefs.getBoolean("auto_speak", true));
        welcome.setChecked(prefs.getBoolean("welcome_speech", true));
        welcomeVariation.setChecked(prefs.getBoolean("welcome_variation", true));
        welcomePersonalized.setChecked(prefs.getBoolean("welcome_personalized", true));
        aiPreload.setChecked(prefs.getBoolean("ai_preload", true));
        ttsPreload.setChecked(prefs.getBoolean("tts_preload", true));
        compact.setChecked(prefs.getBoolean("compact", false));
        threads.setChecked(prefs.getBoolean("tts_threads4", true));
        calculator.setChecked(prefs.getBoolean("calculator_enabled", true));
        musicAccess.setChecked(prefs.getBoolean("music_access_enabled", false));
        animations.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("animations", checked).apply());
        autoSpeak.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("auto_speak", checked).apply());
        welcome.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("welcome_speech", checked).apply());
        welcomeVariation.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("welcome_variation", checked).apply());
        welcomePersonalized.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("welcome_personalized", checked).apply());
        aiPreload.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("ai_preload", checked).apply());
        ttsPreload.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("tts_preload", checked).apply());
        compact.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("compact", checked).apply());
        threads.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("tts_threads4", checked).apply());
        calculator.setOnCheckedChangeListener((button, checked) -> prefs.edit().putBoolean("calculator_enabled", checked).apply());
        musicAccess.setOnCheckedChangeListener((button, checked) -> {
            if (checked) requestMusicPermissionIfNeeded();
            else {
                prefs.edit().putBoolean("music_access_enabled", false).apply();
                updateMusicStatus();
            }
        });

        updateMusicStatus();
        setContentView(scroll);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {}

        if (requestCode == LOG_EXPORT_REQUEST) {
            try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new java.io.IOException("Could not open destination");
                out.write(DebugLog.read(this).getBytes(java.nio.charset.StandardCharsets.UTF_8));
                out.flush();
                Toast.makeText(this, "Debug log exported", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Could not export log: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    }

    private void exportLog() {
        if (!DebugLog.enabled(this) && DebugLog.read(this).trim().isEmpty()) {
            Toast.makeText(this, "Enable debug logging first, then reproduce the problem.", Toast.LENGTH_LONG).show();
            return;
        }
        Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        create.addCategory(Intent.CATEGORY_OPENABLE);
        create.setType("text/plain");
        create.putExtra(Intent.EXTRA_TITLE, "jarvis-debug.log");
        startActivityForResult(create, LOG_EXPORT_REQUEST);
    }

    @Override protected void onResume() {
        super.onResume();
        if (musicStatus != null) updateMusicStatus();
    }

    private void requestMusicPermissionIfNeeded() {
        String permission = Build.VERSION.SDK_INT >= 33
                ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) {
            prefs.edit().putBoolean("music_access_enabled", true).apply();
            updateMusicStatus();
        } else {
            requestPermissions(new String[]{permission}, MUSIC_PERMISSION_REQUEST);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MUSIC_PERMISSION_REQUEST) {
            boolean granted = grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            prefs.edit().putBoolean("music_access_enabled", granted).apply();
            if (musicAccess != null) musicAccess.setChecked(granted);
            updateMusicStatus();
            if (!granted) Toast.makeText(this, "Music permission was not granted", Toast.LENGTH_SHORT).show();
        }
        if (requestCode == STORAGE_PERMISSION_REQUEST && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Storage access granted. JARVIS uses the fixed device model location.", Toast.LENGTH_SHORT).show();
        }
    }

    private void updateMusicStatus() {
        if (musicStatus == null) return;
        String permission = Build.VERSION.SDK_INT >= 33
                ? "android.permission.READ_MEDIA_AUDIO"
                : "android.permission.READ_EXTERNAL_STORAGE";
        boolean granted = Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED;
        boolean enabled = prefs.getBoolean("music_access_enabled", false);
        musicStatus.setText(granted && enabled
                ? "Read only access is enabled. JARVIS can search and play local tracks."
                : "No music library access is active.");
    }

    private void openPermissionSettings() {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Open Android app permissions to manage music access", Toast.LENGTH_LONG).show();
        }
    }

    private void addSection(LinearLayout root, String value) { TextView label = makeText(value.toUpperCase(), 10, ACCENT); label.setTypeface(Typeface.DEFAULT, Typeface.BOLD); label.setPadding(dp(2),dp(18),dp(2),dp(8)); root.addView(label); }
    private CheckBox check(String title, String summary) { CheckBox box = new CheckBox(this); box.setText(title + "\n" + summary); box.setTextSize(14); box.setTextColor(TEXT); box.setPadding(0,dp(5),0,dp(5)); return box; }
}
