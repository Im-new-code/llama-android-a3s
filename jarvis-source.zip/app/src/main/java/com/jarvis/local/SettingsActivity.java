package com.jarvis.local;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

public final class SettingsActivity extends Activity {
    private static final int BG = Color.rgb(7, 9, 14);
    private static final int TEXT = Color.rgb(244, 247, 251);
    private static final int MUTED = Color.rgb(145, 157, 178);
    private static final int ACCENT = Color.rgb(107, 231, 255);

    private SharedPreferences prefs;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeText(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(32));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);

        TextView back = makeText("‹", 34, TEXT);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("Back");
        back.setBackgroundResource(R.drawable.bg_icon_button);
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);
        TextView title = makeText("Settings", 23, TEXT);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleBox.addView(title);
        TextView subtitle = makeText("Tune your private local experience.", 11, MUTED);
        subtitle.setPadding(0, dp(2), 0, 0);
        titleBox.addView(subtitle);
        top.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(top);

        addSection(root, "Appearance");
        CheckBox animations = check("Light animations", "Orb, message and speaking animations.");
        root.addView(animations);

        addSection(root, "Voice");
        CheckBox autoSpeak = check("Speak responses automatically", "Send completed responses to the local TTS queue.");
        root.addView(autoSpeak);

        CheckBox compact = check("Compact conversation", "Reduce vertical spacing between messages.");
        root.addView(compact);

        addSection(root, "Performance");
        CheckBox threads = check("Use four TTS worker threads", "Recommended starting point for this device class.");
        root.addView(threads);

        addSection(root, "TTS tuning");
        TextView speedLabel = makeText("Voice speed", 14, TEXT);
        root.addView(speedLabel);
        SeekBar speed = new SeekBar(this);
        speed.setMax(40);
        speed.setProgress(prefs.getInt("tts_speed", 20));
        speed.setContentDescription("TTS speed");
        speed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                prefs.edit().putInt("tts_speed", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) {}
            @Override public void onStopTrackingTouch(SeekBar bar) {}
        });
        root.addView(speed);

        TextView range = makeText(
                "HFC Male Piper target: length scale 0.90. Speed control will connect during Sherpa integration.",
                11, MUTED);
        range.setPadding(0, dp(2), 0, dp(8));
        root.addView(range);

        addSection(root, "Models");
        TextView info = makeText(
                "LLM   •   external GGUF\nTTS   •   en_US-hfc_male-medium\nSTT   •   Sherpa ONNX\nStorage   •   user controlled",
                13, MUTED);
        info.setBackgroundResource(R.drawable.bg_surface);
        info.setPadding(dp(16), dp(16), dp(16), dp(16));
        root.addView(info);

        addSection(root, "About");
        TextView about = makeText(
                "About JARVIS\nCreator, source code, issues and workflow shortcuts.",
                14, TEXT);
        about.setBackgroundResource(R.drawable.bg_surface_soft);
        about.setPadding(dp(16), dp(14), dp(16), dp(14));
        about.setOnClickListener(v -> startActivity(new Intent(this, AboutActivity.class)));
        root.addView(about);

        animations.setChecked(prefs.getBoolean("animations", true));
        autoSpeak.setChecked(prefs.getBoolean("auto_speak", false));
        compact.setChecked(prefs.getBoolean("compact", false));
        threads.setChecked(prefs.getBoolean("tts_threads4", true));

        animations.setOnCheckedChangeListener((button, checked) ->
                prefs.edit().putBoolean("animations", checked).apply());
        autoSpeak.setOnCheckedChangeListener((button, checked) ->
                prefs.edit().putBoolean("auto_speak", checked).apply());
        compact.setOnCheckedChangeListener((button, checked) ->
                prefs.edit().putBoolean("compact", checked).apply());
        threads.setOnCheckedChangeListener((button, checked) ->
                prefs.edit().putBoolean("tts_threads4", checked).apply());

        setContentView(scroll);
    }

    private void addSection(LinearLayout root, String value) {
        TextView label = makeText(value.toUpperCase(), 10, ACCENT);
        label.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        label.setPadding(dp(2), dp(18), dp(2), dp(8));
        root.addView(label);
    }

    private CheckBox check(String title, String summary) {
        CheckBox box = new CheckBox(this);
        box.setText(title + "\n" + summary);
        box.setTextSize(14);
        box.setTextColor(TEXT);
        box.setPadding(0, dp(5), 0, dp(5));
        return box;
    }
}
