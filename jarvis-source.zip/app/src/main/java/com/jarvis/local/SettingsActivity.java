package com.jarvis.local;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public final class SettingsActivity extends Activity {

    private final int bg = Color.rgb(9, 11, 16);
    private final int text = Color.rgb(244, 247, 251);
    private final int muted = Color.rgb(147, 160, 181);
    private final int accent = Color.rgb(107, 231, 255);

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20, 20, 20, 20);
        root.setBackgroundColor(bg);

        TextView top = make("JARVIS Settings", 24, text);
        top.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(top);

        TextView sub = make(
                "Controls are local and designed for low resource use.",
                12, muted
        );
        sub.setPadding(0, 4, 0, 22);
        root.addView(sub);

        addSection(root, "Appearance");

        CheckBox animations = check(
                "Light animations",
                "Keep subtle orb and message animations enabled.",
                true
        );
        root.addView(animations);

        addSection(root, "Voice");

        CheckBox autoSpeak = check(
                "Speak responses automatically",
                "Send completed local responses to the TTS queue.",
                false
        );
        root.addView(autoSpeak);

        CheckBox compact = check(
                "Compact conversation",
                "Use tighter message spacing on small displays.",
                false
        );
        root.addView(compact);

        addSection(root, "Performance");

        CheckBox fourThreads = check(
                "Use four TTS worker threads",
                "Recommended starting point for this device class.",
                true
        );
        root.addView(fourThreads);

        addSection(root, "TTS tuning");

        TextView speedLabel = make("Voice speed", 14, text);
        root.addView(speedLabel);

        SeekBar speed = new SeekBar(this);
        speed.setMax(40);
        speed.setProgress(20);
        speed.setContentDescription("TTS speed");
        root.addView(speed);

        TextView range = make(
                "The final TTS integration will map this control to the HFC Male Piper speed.",
                11, muted
        );
        range.setPadding(0, 0, 0, 18);
        root.addView(range);

        addSection(root, "Models");

        TextView modelInfo = make(
                "LLM: external GGUF model\n"
                        + "TTS: en_US-hfc_male-medium\n"
                        + "STT: Sherpa ONNX\n"
                        + "Storage: user controlled",
                13, muted
        );
        modelInfo.setBackgroundResource(R.drawable.bg_surface);
        modelInfo.setPadding(16, 16, 16, 16);
        root.addView(modelInfo);

        TextView note = make(
                "No model is bundled into the APK. This keeps updates small and lets you replace models independently.",
                11, muted
        );
        note.setPadding(2, 18, 2, 0);
        root.addView(note);

        animations.setChecked(prefs.getBoolean("animations", true));
        autoSpeak.setChecked(prefs.getBoolean("auto_speak", false));
        compact.setChecked(prefs.getBoolean("compact", false));
        fourThreads.setChecked(prefs.getBoolean("tts_threads4", true));

        animations.setOnCheckedChangeListener(
                (b, checked) -> prefs.edit().putBoolean("animations", checked).apply()
        );
        autoSpeak.setOnCheckedChangeListener(
                (b, checked) -> prefs.edit().putBoolean("auto_speak", checked).apply()
        );
        compact.setOnCheckedChangeListener(
                (b, checked) -> prefs.edit().putBoolean("compact", checked).apply()
        );
        fourThreads.setOnCheckedChangeListener(
                (b, checked) -> prefs.edit().putBoolean("tts_threads4", checked).apply()
        );

        setContentView(root);
    }

    private void addSection(LinearLayout root, String title) {
        TextView t = make(title.toUpperCase(), 11, accent);
        t.setTypeface(null, android.graphics.Typeface.BOLD);
        t.setPadding(2, 18, 2, 8);
        root.addView(t);
    }

    private TextView make(String value, float size, int color) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextSize(size);
        tv.setTextColor(color);
        return tv;
    }

    private CheckBox check(String title, String summary, boolean initial) {
        CheckBox box = new CheckBox(this);
        box.setText(title + "\n" + summary);
        box.setTextSize(14);
        box.setTextColor(text);
        box.setButtonTintList(
                new android.content.res.ColorStateList(
                        new int[][]{new int[]{android.R.attr.state_checked}, new int[]{}},
                        new int[]{accent, muted}
                )
        );
        box.setPadding(0, 5, 0, 5);
        return box;
    }
}
