package com.jarvis.local;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public final class AboutActivity extends Activity {
    private static final int BG = Color.rgb(7, 9, 14);
    private static final int FG = Color.rgb(244, 247, 251);
    private static final int MUTED = Color.rgb(145, 157, 178);
    private static final int ACCENT = Color.rgb(107, 231, 255);

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BG);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(32));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text("‹", 34, FG);
        back.setGravity(Gravity.CENTER);
        back.setBackgroundResource(R.drawable.bg_icon_button);
        back.setContentDescription("Back");
        back.setOnClickListener(v -> finish());
        top.addView(back, new LinearLayout.LayoutParams(dp(46), dp(46)));

        TextView title = text("About JARVIS", 23, FG);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(dp(12), 0, 0, 0);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(46), 1));
        root.addView(top);

        TextView subtitle = text("A private, local first AI built for Android.", 13, MUTED);
        subtitle.setPadding(dp(3), dp(10), dp(3), dp(18));
        root.addView(subtitle);

        TextView hero = text(
                "JARVIS\n\nA lightweight local assistant designed to evolve from a modern chat interface into a full offline voice AI.\n\nCurrent release  •  0.1.1 UI foundation",
                15, FG);
        hero.setBackgroundResource(R.drawable.bg_surface);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        root.addView(hero);

        TextView creator = text("CREATOR", 10, ACCENT);
        creator.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        creator.setPadding(dp(3), dp(22), 0, dp(8));
        root.addView(creator);

        TextView by = text("Im-new-code\nOpen source project and development", 14, FG);
        by.setBackgroundResource(R.drawable.bg_surface_soft);
        by.setPadding(dp(15), dp(14), dp(15), dp(14));
        root.addView(by);

        TextView linksLabel = text("PROJECT LINKS", 10, ACCENT);
        linksLabel.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        linksLabel.setPadding(dp(3), dp(22), 0, dp(8));
        root.addView(linksLabel);

        addLink(root, "GitHub profile", "https://github.com/Im-new-code", ACCENT);
        addLink(root, "JARVIS Android repository", "https://github.com/Im-new-code/llama-android-a3s", FG);
        addLink(root, "Issues and adjustments", "https://github.com/Im-new-code/llama-android-a3s/issues", FG);
        addLink(root, "GitHub Actions", "https://github.com/Im-new-code/llama-android-a3s/actions", FG);

        TextView note = text(
                "Tap any link to open it directly in your browser. No searching through GitHub required.",
                11, MUTED);
        note.setPadding(dp(3), dp(18), dp(3), 0);
        root.addView(note);

        setContentView(scroll);
    }

    private void addLink(LinearLayout root, String label, String url, int color) {
        TextView view = text("↗  " + label, 14, color);
        view.setBackgroundResource(R.drawable.bg_surface_soft);
        view.setPadding(dp(15), dp(14), dp(15), dp(14));
        view.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
            } catch (Exception ignored) {
                Toast.makeText(this, "No browser available", Toast.LENGTH_SHORT).show();
            }
        });
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.setMargins(0, dp(5), 0, 0);
        root.addView(view, params);
    }
}
