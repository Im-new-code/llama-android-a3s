package com.jarvis.local;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class AboutActivity extends Activity {
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
    @Override protected void onCreate(Bundle b){super.onCreate(b); final int bg=Color.rgb(7,9,14),fg=Color.rgb(244,247,251),muted=Color.rgb(145,157,178),accent=Color.rgb(107,231,255);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setPadding(dp(20),dp(18),dp(20),dp(20));
        TextView title=t("About JARVIS",26,fg);title.setTypeface(Typeface.DEFAULT,Typeface.BOLD);root.addView(title);
        TextView sub=t("A private, local first AI built for Android.",13,muted);sub.setPadding(0,dp(4),0,dp(20));root.addView(sub);
        TextView hero=t("JARVIS\n\nDesigned to run locally, keep your data close, and grow from a lightweight chat interface into a full offline voice assistant.\n\nVersion 0.1 • UI foundation",15,fg);hero.setBackgroundResource(R.drawable.bg_surface);hero.setPadding(dp(18),dp(18),dp(18),dp(18));root.addView(hero);
        TextView by=t("Built by Im-new-code",14,accent);by.setTypeface(Typeface.DEFAULT,Typeface.BOLD);by.setPadding(dp(3),dp(22),0,dp(8));root.addView(by);
        addLink(root,"GitHub profile","https://github.com/Im-new-code",accent);
        addLink(root,"JARVIS Android repository","https://github.com/Im-new-code/llama-android-a3s",fg);
        addLink(root,"Issues and adjustments","https://github.com/Im-new-code/llama-android-a3s/issues",fg);
        addLink(root,"GitHub Actions workflows","https://github.com/Im-new-code/llama-android-a3s/actions",fg);
        TextView note=t("Open any link directly in your browser. No GitHub searching required.",11,muted);note.setPadding(dp(3),dp(18),dp(3),0);root.addView(note);
        setContentView(root);
    }
    private void addLink(LinearLayout root,String label,String url,int color){TextView v=t("↗  "+label,14,color);v.setBackgroundResource(R.drawable.bg_surface_soft);v.setPadding(dp(15),dp(14),dp(15),dp(14));v.setOnClickListener(x->{try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception ignored){}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,0);root.addView(v,p);}
}
