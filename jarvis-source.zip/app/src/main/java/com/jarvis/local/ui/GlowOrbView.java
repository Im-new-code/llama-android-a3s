package com.jarvis.local.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

public final class GlowOrbView extends View {

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private float pulse = 0f;
    private ValueAnimator animator;
    private boolean speaking = false;

    public GlowOrbView(Context context) {
        super(context);
        init();
    }

    public GlowOrbView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    private void init() {
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(1800);
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(v -> {
            pulse = (float) v.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    public void setSpeaking(boolean value) { speaking = value; invalidate(); }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float cx = getWidth() / 2f;
        float cy = getHeight() / 2f;
        float base = Math.min(getWidth(), getHeight()) * 0.26f;
        float radius = base + (float) Math.sin(pulse * Math.PI * 2) * base * (speaking ? 0.16f : 0.08f);

        RadialGradient gradient = new RadialGradient(
                cx, cy,
                radius * 2.1f,
                new int[]{0xAA6BE7FF, 0x336BE7FF, 0x006BE7FF},
                new float[]{0f, 0.42f, 1f},
                Shader.TileMode.CLAMP
        );

        paint.setShader(gradient);
        canvas.drawCircle(cx, cy, radius * (speaking ? 2.45f : 2.1f), paint);

        paint.setShader(null);
        paint.setColor(0xFF6BE7FF);
        canvas.drawCircle(cx, cy, radius, paint);

        paint.setColor(0xFF0C121A);
        canvas.drawCircle(cx, cy, radius * 0.45f, paint);

        paint.setColor(0xFFFFFFFF);
        canvas.drawCircle(cx, cy, radius * 0.16f, paint);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) animator.cancel();
        super.onDetachedFromWindow();
    }
}
