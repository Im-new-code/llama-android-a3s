package com.jarvis.local.core;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;

import java.io.File;

/** Resolves Android external-storage document URIs on API 27+ when a real path is available. */
public final class StoragePathResolver {
    private StoragePathResolver() {}

    public static String fromDocumentUri(Uri uri) {
        if (uri == null) return null;
        if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String docId = DocumentsContract.getDocumentId(uri);
            return fromDocumentId(docId);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String fromTreeUri(Uri uri) {
        if (uri == null) return null;
        if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String treeId = DocumentsContract.getTreeDocumentId(uri);
            return fromDocumentId(treeId);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String fromDocumentId(String docId) {
        if (docId == null) return null;
        int colon = docId.indexOf(':');
        if (colon <= 0) return null;
        String volume = docId.substring(0, colon);
        String relative = docId.substring(colon + 1);
        File root;
        if ("primary".equalsIgnoreCase(volume)) {
            root = Environment.getExternalStorageDirectory();
        } else {
            root = new File("/storage", volume);
        }
        File result = relative.isEmpty() ? root : new File(root, relative);
        return result.getAbsolutePath();
    }

    public static final String FIXED_AI_MODELS = "/storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models";

    public static File fixedSmolModel() {
        File f = new File(FIXED_AI_MODELS, "SmolLM2-360M-Instruct-Q4_K_M.gguf");
        return f.isFile() && f.length() > 0 ? f : null;
    }

    public static File fixedHfcMaleDirectory() {
        File dir = new File(FIXED_AI_MODELS, "vits-piper-en_US-hfc_male-medium");
        return isHfcMaleDirectory(dir) ? dir : null;
    }

    public static File findSmolModel(Context context) {
        return fixedSmolModel();
    }

    public static File findHfcMaleDirectory(Context context) {
        return fixedHfcMaleDirectory();
    }

    private static boolean isHfcMaleDirectory(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        File model = new File(dir, "en_US-hfc_male-medium.onnx");
        File tokens = new File(dir, "tokens.txt");
        File data = new File(dir, "espeak-ng-data");
        return model.isFile() && model.length() > 0 && tokens.isFile() && tokens.length() > 0 && data.isDirectory();
    }

    private static File safeFile(String path) {
        if (path == null || path.trim().isEmpty()) return null;
        return new File(path);
    }
}
