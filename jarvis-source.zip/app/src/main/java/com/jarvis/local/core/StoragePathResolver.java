package com.jarvis.local.core;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;

import java.io.File;

/** Resolves Android external-storage document URIs on API 27+ when a real path is available. */
public final class StoragePathResolver {
    private StoragePathResolver() {}

    public static String fromDocumentUri(Uri uri) {
        if (uri == null) return null;
        if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String docId = DocumentsContract.getDocumentId(uri);
            return fromDocumentId(docId);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String fromTreeUri(Uri uri) {
        if (uri == null) return null;
        if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String treeId = DocumentsContract.getTreeDocumentId(uri);
            return fromDocumentId(treeId);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String fromDocumentId(String docId) {
        if (docId == null) return null;
        int colon = docId.indexOf(':');
        if (colon <= 0) return null;
        String volume = docId.substring(0, colon);
        String relative = docId.substring(colon + 1);
        File root;
        if ("primary".equalsIgnoreCase(volume)) {
            root = Environment.getExternalStorageDirectory();
        } else {
            root = new File("/storage", volume);
        }
        File result = relative.isEmpty() ? root : new File(root, relative);
        return result.getAbsolutePath();
    }

    public static File findSmolModel(Context context) {
        String saved = context.getApplicationContext().getSharedPreferences("jarvis", Context.MODE_PRIVATE)
                .getString("llm_model_path", null);
        File savedFile = safeFile(saved);
        if (savedFile != null && savedFile.isFile() && savedFile.length() > 0) return savedFile;
        File found = findByName("SmolLM2-360M-Instruct-Q4_K_M.gguf");
        return found != null ? found : findGgufContaining("smollm2");
    }

    public static File findHfcMaleDirectory(Context context) {
        String saved = context.getApplicationContext().getSharedPreferences("jarvis", Context.MODE_PRIVATE)
                .getString("tts_model_dir", null);
        File savedDir = safeFile(saved);
        if (savedDir != null && isHfcMaleDirectory(savedDir)) return savedDir;

        File root = new File("/storage");
        File[] volumes = root.listFiles();
        if (volumes != null) {
            for (File volume : volumes) {
                File candidate = new File(volume, "AI-Models/vits-piper-en_US-hfc_male-medium");
                if (isHfcMaleDirectory(candidate)) return candidate;
                candidate = new File(volume, "Android/data/com.termux/files/AI-Models/vits-piper-en_US-hfc_male-medium");
                if (isHfcMaleDirectory(candidate)) return candidate;
            }
        }
        File primary = new File(Environment.getExternalStorageDirectory(), "AI-Models/vits-piper-en_US-hfc_male-medium");
        if (isHfcMaleDirectory(primary)) return primary;
        File termux = new File(Environment.getExternalStorageDirectory(), "Android/data/com.termux/files/AI-Models/vits-piper-en_US-hfc_male-medium");
        return isHfcMaleDirectory(termux) ? termux : null;
    }

    private static boolean isHfcMaleDirectory(File dir) {
        return dir != null && dir.isDirectory()
                && new File(dir, "en_US-hfc_male-medium.onnx").isFile()
                && new File(dir, "tokens.txt").isFile()
                && new File(dir, "espeak-ng-data").isDirectory();
    }

    private static File findByName(String name) {
        File root = new File("/storage");
        File[] volumes = root.listFiles();
        if (volumes != null) {
            for (File volume : volumes) {
                File candidate = new File(volume, "AI-Models/" + name);
                if (candidate.isFile() && candidate.length() > 0) return candidate;
                candidate = new File(volume, "Android/data/com.termux/files/AI-Models/" + name);
                if (candidate.isFile() && candidate.length() > 0) return candidate;
            }
        }
        File primary = new File(Environment.getExternalStorageDirectory(), "AI-Models/" + name);
        if (primary.isFile()) return primary;
        File termux = new File(Environment.getExternalStorageDirectory(), "Android/data/com.termux/files/AI-Models/" + name);
        return termux.isFile() ? termux : null;
    }

    private static File findGgufContaining(String needle) {
        File root = new File("/storage");
        File[] volumes = root.listFiles();
        if (volumes != null) {
            for (File volume : volumes) {
                File dir = new File(volume, "AI-Models");
                File[] files = dir.listFiles();
                if (files == null) {
                    dir = new File(volume, "Android/data/com.termux/files/AI-Models");
                    files = dir.listFiles();
                }
                if (files == null) continue;
                for (File f : files) {
                    String n = f.getName().toLowerCase(java.util.Locale.ROOT);
                    if (f.isFile() && n.endsWith(".gguf") && n.contains(needle)) return f;
                }
            }
        }
        return null;
    }

    private static File safeFile(String path) {
        if (path == null || path.trim().isEmpty()) return null;
        return new File(path);
    }
}
