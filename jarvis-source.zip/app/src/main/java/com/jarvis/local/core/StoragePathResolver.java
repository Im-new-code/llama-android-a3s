package com.jarvis.local.core;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.DocumentsContract;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Resolves local model files on the device. */
public final class StoragePathResolver {
    private StoragePathResolver() {}

    public static String fromDocumentUri(Uri uri) {
        if (uri == null) return null;
        if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String docId = DocumentsContract.getDocumentId(uri);
            return fromDocumentId(docId);
        } catch (Exception ignored) {
            return null;
        }
    }

    public static String fromTreeUri(Uri uri) {
        if (uri == null) return null;
        if (!"com.android.externalstorage.documents".equals(uri.getAuthority())) return null;
        try {
            String treeId = DocumentsContract.getTreeDocumentId(uri);
            return fromDocumentId(treeId);
        } catch (Exception ignored) {
            return null;
        }
    }

    private static String fromDocumentId(String docId) {
        if (docId == null) return null;
        int colon = docId.indexOf(':');
        if (colon <= 0) return null;
        String volume = docId.substring(0, colon);
        String relative = docId.substring(colon + 1);
        File root;
        if ("primary".equalsIgnoreCase(volume)) {
            root = Environment.getExternalStorageDirectory();
        } else {
            root = new File("/storage", volume);
        }
        File result = relative.isEmpty() ? root : new File(root, relative);
        return result.getAbsolutePath();
    }

    public static final String FIXED_AI_MODELS = "/storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models";
    private static final String DEFAULT_SMOL_NAME = "SmolLM2-360M-Instruct-Q4_K_M.gguf";
    private static final String SELECTED_LLM_KEY = "selected_llm_model";


    /** Code-cache runtime storage. Android may purge this cache when space is needed. */
    public static File runtimeDirectory(Context context) {
        File dir = new File(context.getApplicationContext().getCodeCacheDir(), "llama-runtime");
        if (!dir.exists()) dir.mkdirs();
        return dir;
    }

    /** Remove runtime files left by versions that stored llama-server under files/. */
    public static long cleanupLegacyRuntime(Context context) {
        File root = context.getApplicationContext().getFilesDir();
        long bytes = deleteTree(new File(root, "llama-runtime"));
        bytes += deleteTree(new File(root, "llama-libs"));
        bytes += deleteTree(new File(root, "llama-server"));
        bytes += deleteTree(new File(root, "llama-server.tmp"));
        return bytes;
    }

    public static long runtimeSize(Context context) {
        return treeSize(runtimeDirectory(context));
    }

    private static long treeSize(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) total += treeSize(child);
        return total;
    }

    private static long deleteTree(File file) {
        if (file == null || !file.exists()) return 0;
        long size = treeSize(file);
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) for (File child : children) deleteTree(child);
        }
        try { file.delete(); } catch (Exception ignored) {}
        return size;
    }

    public static File fixedSmolModel() {
        return new File(FIXED_AI_MODELS, DEFAULT_SMOL_NAME);
    }

    public static File fixedHfcMaleDirectory() {
        File dir = new File(FIXED_AI_MODELS, "vits-piper-en_US-hfc_male-medium");
        return isHfcMaleDirectory(dir) ? dir : null;
    }

    public static File findSmolModel(Context context) {
        File selected = getSelectedLlmModel(context);
        if (selected != null) return selected;
        File smol = fixedSmolModel();
        return smol.isFile() && smol.length() > 0 ? smol : null;
    }

    public static File findHfcMaleDirectory(Context context) {
        return fixedHfcMaleDirectory();
    }

    /** Returns all GGUF models below the known local AI-Models root. */
    public static List<File> discoverGgufModels() {
        List<File> result = new ArrayList<>();
        scanForGguf(new File(FIXED_AI_MODELS), result, 0, 5);
        Collections.sort(result, new Comparator<File>() {
            @Override public int compare(File a, File b) {
                int byName = a.getName().compareToIgnoreCase(b.getName());
                if (byName != 0) return byName;
                return a.getAbsolutePath().compareToIgnoreCase(b.getAbsolutePath());
            }
        });
        return result;
    }

    private static void scanForGguf(File dir, List<File> result, int depth, int maxDepth) {
        if (dir == null || depth > maxDepth || !dir.isDirectory()) return;
        File[] files;
        try {
            files = dir.listFiles();
        } catch (SecurityException e) {
            return;
        }
        if (files == null) return;
        for (File file : files) {
            if (file == null) continue;
            if (file.isDirectory()) {
                scanForGguf(file, result, depth + 1, maxDepth);
            } else if (file.isFile() && file.length() > 0 && file.getName().toLowerCase().endsWith(".gguf")) {
                result.add(file);
            }
        }
    }

    public static File getSelectedLlmModel(Context context) {
        String path = context.getApplicationContext()
                .getSharedPreferences("jarvis", Context.MODE_PRIVATE)
                .getString(SELECTED_LLM_KEY, null);
        if (path != null && !path.trim().isEmpty()) {
            File selected = new File(path);
            if (selected.isFile() && selected.length() > 0 && isUnderModelRoot(selected)) {
                return selected;
            }
        }
        return null;
    }

    public static File ensureDefaultLlmModel(Context context) {
        File current = getSelectedLlmModel(context);
        if (current != null) return current;

        File smol = fixedSmolModel();
        if (smol.isFile() && smol.length() > 0) {
            setSelectedLlmModel(context, smol);
            return smol;
        }

        List<File> models = discoverGgufModels();
        if (!models.isEmpty()) {
            setSelectedLlmModel(context, models.get(0));
            return models.get(0);
        }
        return null;
    }

    public static void setSelectedLlmModel(Context context, File model) {
        if (model == null || !model.isFile() || model.length() <= 0 || !isUnderModelRoot(model)) return;
        context.getApplicationContext().getSharedPreferences("jarvis", Context.MODE_PRIVATE)
                .edit().putString(SELECTED_LLM_KEY, model.getAbsolutePath()).apply();
    }

    public static void clearSelectedLlmModel(Context context) {
        context.getApplicationContext().getSharedPreferences("jarvis", Context.MODE_PRIVATE)
                .edit().remove(SELECTED_LLM_KEY).apply();
    }

    public static boolean isUnderModelRoot(File file) {
        try {
            String root = new File(FIXED_AI_MODELS).getCanonicalPath();
            String path = file.getCanonicalPath();
            return path.equals(root) || path.startsWith(root + File.separator);
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean isHfcMaleDirectory(File dir) {
        if (dir == null || !dir.isDirectory()) return false;
        File model = new File(dir, "en_US-hfc_male-medium.onnx");
        File tokens = new File(dir, "tokens.txt");
        File data = new File(dir, "espeak-ng-data");
        return model.isFile() && model.length() > 0 && tokens.isFile() && tokens.length() > 0 && data.isDirectory();
    }
}
