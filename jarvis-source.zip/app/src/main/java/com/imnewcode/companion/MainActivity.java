package com.imnewcode.companion;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowManager;
import com.imnewcode.companion.live2d.Live2DView;

/** Minimal Live2D companion prototype. The model is shown immediately on launch. */
public final class MainActivity extends Activity {
    private Live2DView live2d;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().setNavigationBarColor(Color.BLACK);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().getDecorView().setSystemUiVisibility(
                0
                | android.view.View.SYSTEM_UI_FLAG_FULLSCREEN
                | android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        live2d = new Live2DView(this);
        setContentView(live2d);
    }

    @Override protected void onStart() {
        super.onStart();
        if (live2d != null) live2d.onStartCompanion();
    }

    @Override protected void onResume() {
        super.onResume();
        if (live2d != null) live2d.onResumeCompanion();
    }

    @Override protected void onPause() {
        if (live2d != null) live2d.onPauseCompanion();
        super.onPause();
    }

    @Override protected void onStop() {
        if (live2d != null) live2d.onStopCompanion();
        super.onStop();
    }

    @Override protected void onDestroy() {
        if (live2d != null) live2d.onDestroyCompanion();
        super.onDestroy();
    }
}
