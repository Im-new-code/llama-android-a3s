package com.imnewcode.companion.live2d;

import android.content.Context;
import android.graphics.PixelFormat;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public final class Live2DView extends GLSurfaceView {
    private final Renderer renderer = new Renderer();
    public Live2DView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 8, 16, 0);
        getHolder().setFormat(PixelFormat.TRANSLUCENT);
        setZOrderOnTop(true);
        Live2DBridge.setContext(context);
        setRenderer(renderer);
        setRenderMode(RENDERMODE_CONTINUOUSLY);
        setOnTouchListener((v, event) -> {
            final float x = event.getX(), y = event.getY();
            queueEvent(() -> {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: Live2DBridge.nativeOnTouchesBegan(x, y); break;
                    case MotionEvent.ACTION_MOVE: Live2DBridge.nativeOnTouchesMoved(x, y); break;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: Live2DBridge.nativeOnTouchesEnded(x, y); break;
                }
            });
            return true;
        });
    }
    public void onStartCompanion() { Live2DBridge.nativeOnStart(); }
    public void onPauseCompanion() { onPause(); Live2DBridge.nativeOnPause(); }
    public void onResumeCompanion() { onResume(); }
    public void onStopCompanion() { Live2DBridge.nativeOnStop(); }
    public void onDestroyCompanion() { Live2DBridge.nativeOnDestroy(); }
    private static final class Renderer implements GLSurfaceView.Renderer {
        @Override public void onSurfaceCreated(javax.microedition.khronos.opengles.GL10 gl, javax.microedition.khronos.egl.EGLConfig config) { Live2DBridge.nativeOnSurfaceCreated(); }
        @Override public void onSurfaceChanged(javax.microedition.khronos.opengles.GL10 gl, int width, int height) { Live2DBridge.nativeOnSurfaceChanged(width, height); }
        @Override public void onDrawFrame(javax.microedition.khronos.opengles.GL10 gl) { Live2DBridge.nativeOnDrawFrame(); }
    }
}
