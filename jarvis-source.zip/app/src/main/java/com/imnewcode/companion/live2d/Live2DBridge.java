package com.imnewcode.companion.live2d;

import android.content.Context;
import java.io.IOException;
import java.io.InputStream;

public final class Live2DBridge {
    private static Context context;
    public static native void nativeOnStart();
    public static native void nativeOnPause();
    public static native void nativeOnStop();
    public static native void nativeOnDestroy();
    public static native void nativeOnSurfaceCreated();
    public static native void nativeOnSurfaceChanged(int width, int height);
    public static native void nativeOnDrawFrame();
    public static native void nativeOnTouchesBegan(float x, float y);
    public static native void nativeOnTouchesEnded(float x, float y);
    public static native void nativeOnTouchesMoved(float x, float y);
    public static void setContext(Context value) { context = value.getApplicationContext(); }
    public static String[] getAssetList(String dirPath) {
        try { return context.getAssets().list(dirPath); } catch (IOException e) { return new String[0]; }
    }
    public static byte[] loadFile(String filePath) {
        try (InputStream in = context.getAssets().open(filePath)) {
            int size = in.available();
            byte[] data = new byte[size];
            int offset = 0;
            while (offset < size) {
                int n = in.read(data, offset, size - offset);
                if (n < 0) break;
                offset += n;
            }
            return offset == size ? data : null;
        } catch (IOException e) { return null; }
    }
    static { System.loadLibrary("live2d"); }
    private Live2DBridge() {}
}
