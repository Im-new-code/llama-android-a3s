package com.imnewcode.companion.live2d;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public final class Live2DBridge {
    private static final String TAG = "Live2DBridge";
    private static Context context;
    private static File debugFile;
    public static native void nativeOnStart();
    public static native void nativeOnPause();
    public static native void nativeOnStop();
    public static native void nativeOnDestroy();
    public static native void nativeOnSurfaceCreated();
    public static native void nativeOnSurfaceChanged(int width, int height);
    public static native void nativeOnDrawFrame();
    public static native void nativeOnTouchesBegan(float x, float y);
    public static native void nativeOnTouchesEnded(float x, float y);
    public static native void nativeOnTouchesMoved(float x, float y);
    public static void setContext(Context value) {
        context = value.getApplicationContext();
        File dir = new File(context.getExternalFilesDir(null), "debug");
        if (!dir.exists()) dir.mkdirs();
        debugFile = new File(dir, "live2d_debug.log");
        appendDebugLog("\n===== Live2D launch " + System.currentTimeMillis() + " =====");
        appendDebugLog("Android=" + android.os.Build.VERSION.RELEASE + " API=" + android.os.Build.VERSION.SDK_INT +
                " ABI=" + android.os.Build.SUPPORTED_ABIS[0] + " device=" + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
    }

    public static synchronized void appendDebugLog(String message) {
        try {
            if (debugFile == null) return;
            String line = java.text.SimpleDateFormat.getDateTimeInstance().format(new java.util.Date()) + " " + message + "\n";
            try (FileOutputStream out = new FileOutputStream(debugFile, true)) {
                out.write(line.getBytes(StandardCharsets.UTF_8));
            }
        } catch (Throwable ignored) {
            // Logging must never break rendering.
        }
    }

    public static synchronized void clearDebugLog() {
        try {
            if (debugFile != null) new FileOutputStream(debugFile, false).close();
        } catch (Throwable ignored) {}
    }

    public static String getDebugLogPath() {
        return debugFile == null ? "" : debugFile.getAbsolutePath();
    }
    public static String[] getAssetList(String dirPath) {
        try { return context.getAssets().list(dirPath); } catch (IOException e) { return new String[0]; }
    }
    public static byte[] loadFile(String filePath) {
        try (InputStream in = context.getAssets().open(filePath)) {
            int size = in.available();
            byte[] data = new byte[size];
            int offset = 0;
            while (offset < size) {
                int n = in.read(data, offset, size - offset);
                if (n < 0) break;
                offset += n;
            }
            return offset == size ? data : null;
        } catch (IOException e) { return null; }
    }
    static { System.loadLibrary("live2d"); }
    private Live2DBridge() {}
}
