package com.imnewcode.companion.live2d;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public final class Live2DBridge {
    private static final String TAG = "Live2DBridge";
    private static Context context;
    private static File debugFile;
    public static native void nativeOnStart();
    public static native void nativeOnPause();
    public static native void nativeOnStop();
    public static native void nativeOnDestroy();
    public static native void nativeOnSurfaceCreated();
    public static native void nativeOnSurfaceChanged(int width, int height);
    public static native void nativeOnDrawFrame();
    public static native void nativeOnTouchesBegan(float x, float y);
    public static native void nativeOnTouchesEnded(float x, float y);
    public static native void nativeOnTouchesMoved(float x, float y);
    public static void setContext(Context value) {
        context = value.getApplicationContext();
        File external = context.getExternalFilesDir(null);
        File base = external != null ? external : context.getFilesDir();
        File dir = new File(base, "debug");
        if (!dir.exists()) dir.mkdirs();
        debugFile = new File(dir, "live2d_debug.log");
        appendDebugLog("===== Live2D launch =====");
        appendDebugLog("Android=" + android.os.Build.VERSION.RELEASE +
                " API=" + android.os.Build.VERSION.SDK_INT +
                " ABI=" + (android.os.Build.SUPPORTED_ABIS.length > 0 ? android.os.Build.SUPPORTED_ABIS[0] : "unknown") +
                " device=" + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
        appendDebugLog("Debug log path=" + debugFile.getAbsolutePath());
    }
    public static synchronized void appendDebugLog(String message) {
        try {
            if (debugFile == null) return;
            String line = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", java.util.Locale.US).format(new java.util.Date())
                    + " [" + Thread.currentThread().getName() + "] " + message + "\n";
            try (FileOutputStream out = new FileOutputStream(debugFile, true)) {
                out.write(line.getBytes(StandardCharsets.UTF_8));
                out.flush();
            }
        } catch (Throwable ignored) {
            // Logging must never break rendering.
        }
    }
    public static synchronized void clearDebugLog() {
        try {
            if (debugFile != null) new FileOutputStream(debugFile, false).close();
        } catch (Throwable ignored) {}
    }

    public static String getDebugLogPath() {
        return debugFile == null ? "" : debugFile.getAbsolutePath();
    }
    public static String[] getAssetList(String dirPath) {
        try {
            String[] result = context.getAssets().list(dirPath);
            appendDebugLog("[ASSET] list \"" + dirPath + "\" -> " + (result == null ? 0 : result.length));
            if (result != null && result.length > 0) {
                StringBuilder b = new StringBuilder();
                for (String name : result) { if (b.length() > 0) b.append(", "); b.append(name); }
                appendDebugLog("[ASSET] entries: " + b);
            }
            return result == null ? new String[0] : result;
        } catch (IOException e) {
            appendDebugLog("[ASSET] ERROR list \"" + dirPath + "\": " + e);
            return new String[0];
        }
    }
    public static byte[] loadFile(String filePath) {
        try (InputStream in = context.getAssets().open(filePath)) {
            java.io.ByteArrayOutputStream buffer = new java.io.ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            int total = 0;
            while ((n = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, n);
                total += n;
            }
            byte[] data = buffer.toByteArray();
            appendDebugLog("[ASSET] loaded " + filePath + " (" + total + " bytes)");
            return data;
        } catch (IOException e) {
            appendDebugLog("[ASSET] ERROR load " + filePath + ": " + e);
            return null;
        }
    }
    static { System.loadLibrary("live2d"); }
    private Live2DBridge() {}
}
