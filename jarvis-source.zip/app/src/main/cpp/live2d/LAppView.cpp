#include "LAppView.hpp"
#include <GLES2/gl2.h>
#include "LAppPal.hpp"
#include "LAppDelegate.hpp"
#include "LAppLive2DManager.hpp"
#include "LAppModel.hpp"
#include "LAppDefine.hpp"
#include "TouchManager_Common.hpp"

using namespace LAppDefine;

LAppView::LAppView() : _touchManager(new TouchManager_Common()) {}
LAppView::~LAppView() { delete _touchManager; }

void LAppView::Initialize(int width, int height) {
    LAppView_Common::Initialize(width, height);
}

void LAppView::Render() {
    LAppLive2DManager::GetInstance()->OnUpdate();
}

void LAppView::PreModelDraw(LAppModel& model) {
    (void)model;
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);
}

void LAppView::PostModelDraw(LAppModel& model) { (void)model; }

void LAppView::OnTouchesBegan(float x, float y) const {
    _touchManager->TouchesBegan(x, y);
}

void LAppView::OnTouchesMoved(float x, float y) const {
    _touchManager->TouchesMoved(x, y);
    float viewX = TransformViewX(_touchManager->GetX());
    float viewY = TransformViewY(_touchManager->GetY());
    LAppLive2DManager::GetInstance()->OnDrag(viewX, viewY);
}

void LAppView::OnTouchesEnded(float x, float y) {
    (void)x; (void)y;
    LAppLive2DManager::GetInstance()->OnDrag(0.0f, 0.0f);
    float viewX = TransformViewX(_touchManager->GetX());
    float viewY = TransformViewY(_touchManager->GetY());
    LAppLive2DManager::GetInstance()->OnTap(viewX, viewY);
}
