/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

#include "JniBridgeC.hpp"
#include <algorithm>
#include <jni.h>
#include "LAppDelegate.hpp"
#include "LAppPal.hpp"

using namespace Csm;

static JavaVM* g_JVM; // JavaVM is valid for all threads, so just save it globally
static jclass  g_JniBridgeJavaClass;
static jmethodID g_GetAssetsMethodId;
static jmethodID g_LoadFileMethodId;

JNIEnv* GetEnv()
{
    if (g_JVM == nullptr)
    {
        return nullptr;
    }

    JNIEnv* env = nullptr;
    const jint result = g_JVM->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6);
    if (result == JNI_OK)
    {
        return env;
    }

#if defined(__ANDROID__)
    if (result == JNI_EDETACHED)
    {
        if (g_JVM->AttachCurrentThread(&env, nullptr) == JNI_OK)
        {
            return env;
        }
    }
#endif
    return nullptr;
}

// The VM calls JNI_OnLoad when the native library is loaded
jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved)
{
    g_JVM = vm;

    JNIEnv *env;
    if (vm->GetEnv(reinterpret_cast<void **>(&env), JNI_VERSION_1_6) != JNI_OK)
    {
        return JNI_ERR;
    }

    jclass clazz = env->FindClass("com/imnewcode/companion/live2d/Live2DBridge");
    if (clazz == nullptr)
    {
        return JNI_ERR;
    }
    g_JniBridgeJavaClass = reinterpret_cast<jclass>(env->NewGlobalRef(clazz));
    env->DeleteLocalRef(clazz);
    g_GetAssetsMethodId = env->GetStaticMethodID(g_JniBridgeJavaClass, "getAssetList", "(Ljava/lang/String;)[Ljava/lang/String;");
    g_LoadFileMethodId = env->GetStaticMethodID(g_JniBridgeJavaClass, "loadFile", "(Ljava/lang/String;)[B");

    return JNI_VERSION_1_6;
}

void JNICALL JNI_OnUnload(JavaVM *vm, void *reserved)
{
    JNIEnv *env = GetEnv();
    env->DeleteGlobalRef(g_JniBridgeJavaClass);
}

void AppendDebugLogFromNative(const char* message)
{
    JNIEnv* env = GetEnv();
    if (env == nullptr || g_JniBridgeJavaClass == nullptr || message == nullptr)
    {
        return;
    }

    jmethodID logMethod = env->GetStaticMethodID(
        g_JniBridgeJavaClass, "appendDebugLog", "(Ljava/lang/String;)V");
    if (logMethod == nullptr)
    {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return;
    }

    jstring msg = env->NewStringUTF(message);
    if (msg == nullptr)
    {
        if (env->ExceptionCheck()) env->ExceptionClear();
        return;
    }

    env->CallStaticVoidMethod(g_JniBridgeJavaClass, logMethod, msg);
    env->DeleteLocalRef(msg);

    if (env->ExceptionCheck())
    {
        env->ExceptionClear();
    }
}

Csm::csmVector<Csm::csmString>JniBridgeC::GetAssetList(const Csm::csmString& path)
{
    JNIEnv *env = GetEnv();
    jstring jpath = env->NewStringUTF(path.GetRawString());
    jobjectArray obj = reinterpret_cast<jobjectArray>(env->CallStaticObjectMethod(g_JniBridgeJavaClass, g_GetAssetsMethodId, jpath));
    env->DeleteLocalRef(jpath);
    if (env->ExceptionCheck())
    {
        env->ExceptionClear();
        return Csm::csmVector<Csm::csmString>();
    }
    if (obj == nullptr)
    {
        return Csm::csmVector<Csm::csmString>();
    }
    unsigned int size = static_cast<unsigned int>(env->GetArrayLength(obj));
    Csm::csmVector<Csm::csmString> list(size);
    for (unsigned int i = 0; i < size; i++)
    {
        jstring jstr = reinterpret_cast<jstring>(env->GetObjectArrayElement(obj, i));
        const char* chars = env->GetStringUTFChars(jstr, nullptr);
        list.PushBack(Csm::csmString(chars));
        env->ReleaseStringUTFChars(jstr, chars);
        env->DeleteLocalRef(jstr);
    }
    env->DeleteLocalRef(obj);
    return list;
}

char* JniBridgeC::LoadFileAsBytesFromJava(const char* filePath, unsigned int* outSize)
{
    JNIEnv *env = GetEnv();

    // ファイルロード
    jstring jpath = env->NewStringUTF(filePath);
    jbyteArray obj = (jbyteArray)env->CallStaticObjectMethod(g_JniBridgeJavaClass, g_LoadFileMethodId, jpath);
    env->DeleteLocalRef(jpath);
    if (env->ExceptionCheck())
    {
        env->ExceptionClear();
        return NULL;
    }

    // ファイルが見つからなかったらnullが返ってくるためチェック
    if (!obj)
    {
        return NULL;
    }

    *outSize = static_cast<unsigned int>(env->GetArrayLength(obj));

    char* buffer = new char[*outSize];
    env->GetByteArrayRegion(obj, 0, *outSize, reinterpret_cast<jbyte *>(buffer));
    env->DeleteLocalRef(obj);

    return buffer;
}

extern "C"
{
    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnStart(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnStart();
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnPause(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnPause();
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnStop(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnStop();
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnDestroy(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnDestroy();
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnSurfaceCreated(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->OnSurfaceCreate();
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnSurfaceChanged(JNIEnv *env, jclass type, jint width, jint height)
    {
        LAppDelegate::GetInstance()->OnSurfaceChanged(width, height);
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnDrawFrame(JNIEnv *env, jclass type)
    {
        LAppDelegate::GetInstance()->Run();
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnTouchesBegan(JNIEnv *env, jclass type, jfloat pointX, jfloat pointY)
    {
        LAppDelegate::GetInstance()->OnTouchBegan(pointX, pointY);
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnTouchesEnded(JNIEnv *env, jclass type, jfloat pointX, jfloat pointY)
    {
        LAppDelegate::GetInstance()->OnTouchEnded(pointX, pointY);
    }

    JNIEXPORT void JNICALL
    Java_com_imnewcode_companion_live2d_Live2DBridge_nativeOnTouchesMoved(JNIEnv *env, jclass type, jfloat pointX, jfloat pointY)
    {
        LAppDelegate::GetInstance()->OnTouchMoved(pointX, pointY);
    }
}
