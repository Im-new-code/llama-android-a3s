#include "LAppDefine.hpp"
namespace LAppDefine {
using namespace Csm;
const csmChar* ResourcesPath = "";
const csmChar* MotionGroupIdle = "Idle";
const csmChar* MotionGroupTapBody = "Tap";
const csmChar* HitAreaNameHead = "Head";
const csmChar* HitAreaNameBody = "Body";
const csmInt32 PriorityNone = 0;
const csmInt32 PriorityIdle = 1;
const csmInt32 PriorityNormal = 2;
const csmInt32 PriorityForce = 3;
const csmBool DebugLogEnable = true;
const csmBool DebugTouchLogEnable = false;
const CubismFramework::Option::LogLevel CubismLoggingLevel = CubismFramework::Option::LogLevel_Warning;
}
