#pragma once
#include <CubismFramework.hpp>
namespace LAppDefine {
using namespace Csm;
extern const csmChar* ResourcesPath;
extern const csmChar* MotionGroupIdle;
extern const csmChar* MotionGroupTapBody;
extern const csmChar* HitAreaNameHead;
extern const csmChar* HitAreaNameBody;
extern const csmInt32 PriorityNone;
extern const csmInt32 PriorityIdle;
extern const csmInt32 PriorityNormal;
extern const csmInt32 PriorityForce;
extern const csmBool DebugLogEnable;
extern const csmBool DebugTouchLogEnable;
extern const CubismFramework::Option::LogLevel CubismLoggingLevel;
}
