#pragma once
#include <GLES2/gl2.h>
#include "LAppView_Common.hpp"
class TouchManager_Common;
class LAppModel;
class LAppView : public LAppView_Common {
public:
    LAppView();
    ~LAppView() override;
    void Initialize(int width, int height) override;
    void Render();
    void OnTouchesBegan(float x, float y) const;
    void OnTouchesMoved(float x, float y) const;
    void OnTouchesEnded(float x, float y);
    void PreModelDraw(LAppModel& model);
    void PostModelDraw(LAppModel& model);
private:
    TouchManager_Common* _touchManager;
};
