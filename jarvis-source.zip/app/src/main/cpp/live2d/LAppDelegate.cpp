/**
 * Copyright(c) Live2D Inc. All rights reserved.
 *
 * Use of this source code is governed by the Live2D Open Software license
 * that can be found at https://www.live2d.com/eula/live2d-open-software-license-agreement_en.html.
 */

#include "LAppDelegate.hpp"
#include <iostream>
#include <GLES2/gl2.h>
#include <sstream>
#include "LAppView.hpp"
#include "LAppPal.hpp"
#include "LAppDefine.hpp"
#include "LAppLive2DManager.hpp"
#include "LAppTextureManager.hpp"
#include "LAppModel.hpp"
#include "JniBridgeC.hpp"

#include <Rendering/OpenGL/CubismShader_OpenGLES2.hpp>

using namespace Csm;
using namespace std;
using namespace LAppDefine;

namespace {
    LAppDelegate* s_instance = NULL;
}

LAppDelegate* LAppDelegate::GetInstance()
{
    if (s_instance == NULL)
    {
        s_instance = new LAppDelegate();
    }

    return s_instance;
}

void LAppDelegate::ReleaseInstance()
{
    if (s_instance != NULL)
    {
        delete s_instance;
    }

    s_instance = NULL;
}


void LAppDelegate::OnStart()
{
    _isActive = true;
    LAppPal::PrintLogLn("[LIFECYCLE] OnStart");
}

void LAppDelegate::OnPause()
{
    LAppPal::PrintLogLn("[LIFECYCLE] OnPause");
}

void LAppDelegate::OnStop()
{
    LAppPal::PrintLogLn("[LIFECYCLE] OnStop");
    if (_view)
    {
        delete _view;
        _view = NULL;
    }
    if (_textureManager)
    {
        delete _textureManager;
        _textureManager = NULL;
    }

    // リソースを解放
    LAppLive2DManager::ReleaseInstance();

    CubismFramework::Dispose();
}

void LAppDelegate::OnDestroy()
{
    LAppPal::PrintLogLn("[LIFECYCLE] OnDestroy");
    ReleaseInstance();
}

void LAppDelegate::Run()
{
    // 時間更新
    LAppPal::UpdateTime();

    static bool firstFrameLogged = false;
    if (!firstFrameLogged)
    {
        firstFrameLogged = true;
        const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
        const char* glsl = reinterpret_cast<const char*>(glGetString(GL_SHADING_LANGUAGE_VERSION));
        const char* renderer = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
        const char* vendor = reinterpret_cast<const char*>(glGetString(GL_VENDOR));
        LAppPal::PrintLogLn("[GL] first frame: view=%p size=%dx%d GL_VERSION=%s GLSL=%s renderer=%s vendor=%s",
            _view, _width, _height, version ? version : "<null>", glsl ? glsl : "<null>",
            renderer ? renderer : "<null>", vendor ? vendor : "<null>");
    }

    //画面の初期化
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearDepthf(1.0f);

    //描画更新
    if (_view != NULL)
    {
        _view->Render();
    }

    GLenum err = glGetError();
    if (err != GL_NO_ERROR)
    {
        static GLenum lastError = GL_NO_ERROR;
        if (err != lastError)
        {
            lastError = err;
            LAppPal::PrintLogLn("[GL] glGetError=0x%04X", static_cast<unsigned int>(err));
        }
    }

}

void LAppDelegate::OnSurfaceCreate()
{
    const char* version = reinterpret_cast<const char*>(glGetString(GL_VERSION));
    const char* renderer = reinterpret_cast<const char*>(glGetString(GL_RENDERER));
    const char* vendor = reinterpret_cast<const char*>(glGetString(GL_VENDOR));
    LAppPal::PrintLogLn("[GL] surface created: version=%s renderer=%s vendor=%s",
        version ? version : "<null>", renderer ? renderer : "<null>", vendor ? vendor : "<null>");

    //テクスチャサンプリング設定
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    //透過設定
    glEnable(GL_BLEND);
    glBlendFunc(GL_ONE, GL_ONE_MINUS_SRC_ALPHA);

    if (_textureManager == nullptr)
    {
        _textureManager = new LAppTextureManager();
    }
    else
    {
        // 無効になっているOpenGLリソースを破棄
        _textureManager->ReleaseInvalidTextures();
    }
    if (_view != NULL)
    {
        delete _view;
    }
    _view = new LAppView();
    LAppPal::UpdateTime();

    //Initialize cubism
    if (!CubismFramework::IsInitialized())
    {
        LAppPal::PrintLogLn("[CUBISM] initializing framework");
        CubismFramework::Initialize();
        LAppPal::PrintLogLn("[CUBISM] framework initialized");
    }
    else
    {
        LAppPal::PrintLogLn("[CUBISM] framework already initialized");
    }
}

void LAppDelegate::OnSurfaceChanged(float width, float height)
{
    if (width <= 0 || height <= 0)
    {
        LAppPal::PrintLogLn("[GL] invalid surface size: %.0fx%.0f", width, height);
        return;
    }

    glViewport(0, 0, width, height);
    _width = width;
    _height = height;
    LAppPal::PrintLogLn("[GL] surface changed: %.0fx%.0f", width, height);

    //AppViewの初期化
    if (_view == NULL)
    {
        LAppPal::PrintLogLn("[GL] ERROR: view is null during surface change");
        return;
    }
    _view->Initialize(width, height);
    // Create the model only after a valid surface size is known.
    LAppLive2DManager::GetInstance()->SetRenderTargetSize(width, height);
}

void LAppDelegate::SetSceneIndex(int index)
{
    _SceneIndex = index;
}

LAppDelegate::LAppDelegate():
    _cubismOption(),
    _captured(false),
    _SceneIndex(0),
    _mouseX(0.0f),
    _mouseY(0.0f),
    _isActive(true),
    _textureManager(NULL),
    _view(NULL),
    _width(0),
    _height(0)
{
    // Setup Cubism
    _cubismOption.LogFunction = LAppPal::PrintMessageLn;
    _cubismOption.LoggingLevel = LAppDefine::CubismLoggingLevel;
    _cubismOption.LoadFileFunction = LAppPal::LoadFileAsBytes;
    _cubismOption.ReleaseBytesFunction = LAppPal::ReleaseBytes;
    CubismFramework::CleanUp();
    CubismFramework::StartUp(&_cubismAllocator, &_cubismOption);
}

LAppDelegate::~LAppDelegate()
{
}

void LAppDelegate::OnTouchBegan(double x, double y)
{
    _mouseX = static_cast<float>(x);
    _mouseY = static_cast<float>(y);

    if (_view != NULL)
    {
        _captured = true;
        _view->OnTouchesBegan(_mouseX, _mouseY);
    }
}

void LAppDelegate::OnTouchEnded(double x, double y)
{
    _mouseX = static_cast<float>(x);
    _mouseY = static_cast<float>(y);

    if (_view != NULL)
    {
        _captured = false;
        _view->OnTouchesEnded(_mouseX, _mouseY);
    }
}

void LAppDelegate::OnTouchMoved(double x, double y)
{
    _mouseX = static_cast<float>(x);
    _mouseY = static_cast<float>(y);

    if (_captured && _view != NULL)
    {
        _view->OnTouchesMoved(_mouseX, _mouseY);
    }
}
