# Prototype build intentionally has no minification rules.
