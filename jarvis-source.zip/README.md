# JARVIS Android

Lightweight offline assistant foundation for low end Android devices.

## Current architecture

JARVIS is deliberately split into small native components so the app can grow without rebuilding the whole design around one giant Activity.

- `MainActivity`: modern lightweight chat UI
- `TtsManager`: Sherpa ONNX Piper VITS speech generation and AudioTrack playback
- `SentenceQueue`: sentence by sentence generation/playback pipeline
- `ConversationManager`: conversation state and message history
- `LlmEngine`: interface for the local llama.cpp backend
- `SttEngine`: interface for future Sherpa ONNX speech recognition
- `JarvisWidgetProvider`: optional Android home screen widget
- `SettingsActivity`: local preferences and UI controls

## Important device assumptions

Target device is Android 8.1, ARM64, about 3 GB RAM.

The app itself does not bundle a large language model or the Piper model. Models are kept in user storage and can be changed without rebuilding the APK.

Expected TTS model directory:

`/storage/emulated/0/AI-Models/vits-piper-en_US-hfc_male-medium/`

Expected files:

- `en_US-hfc_male-medium.onnx`
- `tokens.txt`
- `espeak-ng-data/`

## Build

The GitHub Actions workflow can download the Sherpa ONNX AAR and build the project.

The project intentionally avoids network based runtime AI dependencies.

## Roadmap

### v0.1
- Modern local AI UI
- TTS integration
- Sentence queue
- Settings
- Home screen widget
- Lightweight animations
- Conversation shell

### v0.2
- Native llama.cpp JNI bridge or local CLI service
- Streaming text generation
- LLM response to TTS

### v0.3
- Offline Sherpa ONNX STT
- Voice conversation mode

### v0.4
- Wake word
- Interruption
- Local memory
- Controlled phone actions

## Source archive workflow

This archive is meant to be the canonical source snapshot. GitHub Actions can fetch it from a public raw GitHub URL, extract it, then build with Gradle.

Do not put the 250 MB+ language model in this archive.


## UI 0.1.1

This revision includes right aligned user bubbles, a non clipping vector settings button, an expanding message composer, a full screen composer, per message Copy/Speak/Share actions, a speaking visualizer, a premium dark UI refresh, and an About page with direct GitHub shortcuts. The LLM and Sherpa TTS bridges remain modular placeholders until their native integration is added.
