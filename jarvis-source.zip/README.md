# AI Companion Prototype

Minimal standalone Android Live2D prototype. This is intentionally separate from the JARVIS chatbot app.

## What this prototype does

- Launches directly into the Live2D model.
- Uses Live2D Cubism Native 5-r.5 + OpenGL ES 2.
- Uses the bundled Koharu sample model only to validate the renderer/runtime.
- Idle motion, physics, blinking/breathing, tap motions and gaze dragging are provided by the model/framework.
- Targets Android API 27+ and arm64-v8a for the OPPO A3s class device.
- No LLM, TTS, STT, chatbot screens, settings, widgets or background services are included yet.

## Build

Use the existing GitHub Actions workflow supplied with this project. It downloads the source archive, supplies the Android toolchain and builds the debug APK.

The workflow also downloads Sherpa and builds llama-cli because that is part of the user's existing build pipeline. This prototype does not link or use either dependency.

## Model/license note

Koharu is included strictly as the technical prototype model. Replace it with an original/licensed Live2D model before shipping a final companion product.

See `app/src/main/assets/koharu/LICENSE_NOTICE.txt`, `app/src/main/cpp/live2d/sdk/Core/LICENSE.md`, and `app/src/main/cpp/live2d/sdk/Framework/LICENSE.md` for the bundled licenses/notices.


## Runtime debug log

The prototype now persists Java and native Live2D diagnostics to:
`Android/data/com.imnewcode.companion/files/debug/live2d_debug.log`

The file is created automatically on launch. It records lifecycle events, EGL/OpenGL renderer information, asset/model discovery, model/texture loading failures, and GL errors. Logging is best-effort and never intentionally blocks rendering.

For this diagnostic build, the GLSurfaceView is opaque rather than a top-most translucent surface because older Android/Adreno devices can have composition problems with translucent GL surfaces.


## v0.1.5

Bundles the Live2D Cubism OpenGL ES2 framework shaders in Android assets. The Cubism Android ES2 shader loader requests these shader files by filename at runtime, so they must be packaged as application assets. Also adds an explicit CMake project declaration and updates the app version.
