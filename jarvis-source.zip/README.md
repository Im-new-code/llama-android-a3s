# JARVIS Android

Version 0.1.4. Lightweight local first assistant UI foundation for Android 8.1 and newer.

## New in 0.1.4

* AI responses have inline Copy, Speak, Share and Retry actions.
* User messages use long press for Copy, Share and Select text instead of inline controls.
* Added a real app launcher icon with an adaptive Android icon.
* Improved widget metadata and preview configuration.
* Added a read only local music library permission toggle using Android MediaStore.
* Added simple play, pause, resume and stop music commands in the conversation layer.
* Added a deterministic calculator path for arithmetic so simple calculations do not need the language model.
* Typing stays focused after send, and the chat scrolls toward the newest message.

The LLM and Sherpa TTS bridges remain isolated so they can be connected without redesigning the UI.


## Capability preservation
This UI revision keeps the existing conversation, LLM engine, TTS engine, STT interface, calculator, local music manager, widget, settings, and About link architecture. The LLM and Sherpa TTS bridges remain intentionally modular integration points and are not replaced by UI code.
