# JARVIS 0.5.3

JARVIS is a private Android assistant tuned for the OPPO A3s class of hardware. The selected GGUF remains on the user's storage and is loaded by a persistent local llama.cpp server during startup. TTS and AI initialization run in parallel.

## 0.5.3 focus

- Persistent llama-server remains loaded between messages.
- Lower-latency inference profile: 512-token server context, one server slot, four generation threads, shorter 80-token response cap, shorter conversation history and no verbose native server logging during normal use.
- HFC Male Piper TTS stays warm and uses one continuous AudioTrack for a response queue to avoid sentence-to-sentence audio clicks and abrupt cuts.
- TTS defaults to two worker threads on the A3s to reduce CPU contention with the LLM. Four-thread TTS remains optional in Settings.
- Runtime extraction moved to Android's code-cache area so the system can reclaim it when storage is tight. Legacy runtime files under the old app-private location are cleaned up on startup.
- Debug logs are capped at 2 MiB and detailed native logging is off by default.
- Android SpeechRecognizer based STT is integrated with offline recognition preferred when the installed speech provider supports it. This is not a guaranteed offline backend; a truly offline recognizer requires an offline STT model/provider.
- The microphone button starts a hands-free continuous voice conversation mode. JARVIS listens, sends the recognized phrase, speaks the response, then listens again.
- The main conversation view limits retained message views to avoid UI slowdown during very long sessions.

## Storage

GGUF and Piper model files are read directly from:

`/storage/6D3D-1AFB/Android/data/com.termux/files/AI-Models`

JARVIS does not copy the user-selected GGUF or TTS model into the app. The bundled llama-server executable and its native dependencies must still be extracted somewhere executable by Android; 0.5.3 puts this temporary runtime in the app's code cache instead of the ordinary files directory. Settings includes a runtime-cache cleanup action.

## Voice conversation

Tap the microphone button beside the message field. The first use requests microphone permission. In voice mode, partial speech recognition is shown in the composer, the final recognition is sent automatically, and the response is spoken automatically. Tap the microphone button again to leave voice mode.

The Android SpeechRecognizer API can be backed by the device's installed speech service. JARVIS requests `EXTRA_PREFER_OFFLINE=true`, but the API does not guarantee that the provider will stay offline.

## Build

The repository workflow builds an arm64-v8a debug APK with Java 17, Android API 35 and llama.cpp pinned to `b78db3b`.
